# CSVBolt — Trabajo Práctico Final (Demo funcional)

**Estado:** listo para corrección ✅  
**Stack:** Vite + React (client) · Express + TypeScript (server) · SQLite + Drizzle ORM

---

## 🚀 Qué incluye y cómo mapea a la consigna

### Básico (obligatorias)
- **Persistencia real en BD** con **SQLite + Drizzle** y modelos (`shared/schema.ts`).  
- **Vista de datos** con **paginación, búsqueda y orden** en el servidor (`GET /api/files/:id/data`).  
- **Exportación CSV** vía **descarga** (`GET /api/files/:id/download`).  
- **Validación en servidor** al editar filas (reglas básicas de tipos/requeridos).  
  > Páginas: *Dashboard*, *Files*, *File Viewer*

### Intermedio (≥2 implementadas)
- **Autenticación y roles** (*viewer*, *editor*, *admin*) con JWT (`/api/auth/*`).  
- **Gestión de múltiples archivos**: subida, listado, borrado, stats (dashboard).

### Avanzado (≥1 implementada)
- **Merge de CSV** (`POST /api/merge`)  
  - **Público / viewer (sin login)** → devuelve **CSV descargable**.  
  - **Editor/Admin** → **persiste** dataset y devuelve `resultFileId`.

---

## 🧩 Arquitectura de carpetas
```
CsvBolt/
├─ client/                 # Vite + React (UI que generó Replit)
├─ server/                 # Express + TypeScript (API)
│  ├─ database/sqlite.ts   # conexión Drizzle SQLite
│  ├─ middleware/          # auth, uploads
│  ├─ services/            # procesamiento CSV
│  ├─ routes.ts            # endpoints (incluye /health, /merge, /download)
│  └─ index.ts             # bootstrap del server y Vite
├─ shared/schema.ts        # esquemas Drizzle + tipos
├─ README.md               # (este archivo)
├─ README_DELIVERY.md      # notas de entrega rápida
└─ .env.example            # variables a copiar a .env
```

---

## ▶️ Cómo correr
```bash
# 1) Instalar
npm install

# 2) Variables
cp .env.example .env
# Editar .env y definir:
# JWT_SECRET=un-secreto-aleatorio

# 3) Dev
npm run dev
# Servirá API + client en el mismo puerto (PORT). Por defecto: 5000
```

> **Healthcheck:** `GET /health` ⇒ `true`

---

## 🔑 Usuarios y roles
- **Registro:** `POST /api/auth/register` `{ username, email, password, role }`  
- **Login:** `POST /api/auth/login` `{ username, password }` → `{ token }`  
- Uso del token: `Authorization: Bearer <token>`

**Roles:**
- `viewer`: puede ver, buscar, descargar; **merge** en modo *descarga* (no persiste).
- `editor`/`admin`: además puede subir, editar, borrar, y **guardar** el merge como dataset.

---

## 📡 Endpoints principales

### Archivos (Files)
- `GET /api/files` — lista de archivos (autenticado).
- `GET /api/files/:id` — detalle (autenticado).
- `GET /api/files/:id/data?limit=&offset=&search=&orderBy=&order=` — datos paginados con búsqueda/orden.
- `GET /api/files/:id/download` — **descarga CSV** (público si `status=completed`, o dueño/admin).
- `POST /api/files/upload` — subida CSV (editor/admin).
- `PATCH /api/files/:id` — edición metadatos (editor/admin).
- `DELETE /api/files/:id` — borrar (editor/admin).

### Merge
- `POST /api/merge` — body: `{ sourceFileId, targetFileId, mergeKey, type: "inner"|"left" }`  
  - **viewer/sin login:** descarga CSV.  
  - **editor/admin:** crea dataset y responde `{ resultFileId }`.

### Auth
- `POST /api/auth/register` — crea usuario.
- `POST /api/auth/login` — devuelve `token`.

### Health
- `GET /health` — devuelve `true`.

---

## 🧪 Pruebas paso a paso (para la cátedra)

1. **Health:** `GET /health` ⇒ `true`  
2. **Subir 2 CSV:** desde la UI (Dashboard → Upload) o `POST /api/files/upload`.  
3. **Ver datos:** abrir un archivo en *View* → tabla con **búsqueda** y **paginación**.  
4. **Descargar:** botón **Download** o `GET /api/files/:id/download`.  
5. **Merge (público):** `POST /api/merge` sin token ⇒ descarga CSV resultado.  
6. **Merge (editor/admin):** `POST /api/merge` con token ⇒ responde `{ resultFileId }` y aparece en *Files*.

---

## 📷 Capturas sugeridas (agregalas en `docs/screenshots/` y actualizá los paths)
- `docs/screenshots/1-dashboard.png` — Dashboard con métricas
- `docs/screenshots/2-files.png` — Listado de archivos
- `docs/screenshots/3-viewer.png` — Vista de datos con búsqueda/paginación
- `docs/screenshots/4-download.png` — Descarga CSV
- `docs/screenshots/5-merge-public.png` — Merge público (descarga)
- `docs/screenshots/6-merge-admin.png` — Merge guardado (resultFileId)

En el README, podés insertar así:
```md
![Dashboard](docs/screenshots/1-dashboard.png)
```

---

## ⚙️ Variables de entorno
Archivo `.env` basado en `.env.example`:
```
JWT_SECRET=tu-secreto
PORT=5000
```

---

## 🧱 Decisiones técnicas
- **SQLite + Drizzle** por simplicidad y migraciones rápidas en TP.
- **Streaming CSV** en descarga para soportar archivos grandes.
- **Join** del merge en servidor por **clave** con `inner`/`left`, con comportamiento diferenciado por rol.

---

## ✅ Checklist de entrega
- [x] Básico: persistencia + viewer con filtros/orden/paginación + descarga CSV
- [x] Intermedio: auth+roles y múltiples archivos
- [x] Avanzado: merge (público descarga / editor persiste)
- [x] Healthcheck
- [x] README para cátedra

---

## 👩‍🏫 Defensa rápida (guion)
1. Explicá arquitectura (client/server/shared).  
2. Mostrá upload → dashboard actualiza stats.  
3. Abrí un file → búsqueda, orden, paginación.  
4. Descargá CSV.  
5. Merge sin login (descarga).  
6. Login editor → merge nuevamente (persiste) → aparece en Files.

¡Éxitos!
