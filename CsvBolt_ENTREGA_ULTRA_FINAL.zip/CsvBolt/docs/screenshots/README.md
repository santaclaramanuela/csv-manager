# Capturas sugeridas

- 1-dashboard.png
- 2-files.png
- 3-viewer.png
- 4-download.png
- 5-merge-public.png
- 6-merge-admin.png

Colocá las imágenes en esta carpeta y enlazalas desde el README.
