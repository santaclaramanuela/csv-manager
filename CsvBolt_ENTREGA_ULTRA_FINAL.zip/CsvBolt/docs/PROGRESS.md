# Progreso/Bitácora de desarrollo

Usado por el script de commits para simular el avance incremental.
Cada commit agrega una sección con el hito correspondiente.
