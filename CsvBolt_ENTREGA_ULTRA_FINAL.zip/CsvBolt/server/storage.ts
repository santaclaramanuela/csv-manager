import { eq, desc, and, like, count, sql } from "drizzle-orm";
import { db } from "./database/sqlite";
import * as schema from "@shared/schema";
import type {
  User,
  InsertUser,
  CsvFile,
  InsertCsvFile,
  CsvColumn,
  InsertCsvColumn,
  CsvData,
  InsertCsvData,
  MergeOperation,
  InsertMergeOperation,
  FileWithStats,
  DashboardStats,
  TableRow
} from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean>;

  // File management
  createCsvFile(file: InsertCsvFile): Promise<CsvFile>;
  getCsvFile(id: string): Promise<CsvFile | undefined>;
  getCsvFilesByUser(userId: string, limit?: number, offset?: number): Promise<CsvFile[]>;
  getAllCsvFiles(limit?: number, offset?: number): Promise<CsvFile[]>;
  updateCsvFileStatus(id: string, status: string, errorMessage?: string): Promise<void>;
  deleteCsvFile(id: string): Promise<void>;
  getFileWithStats(id: string): Promise<FileWithStats | undefined>;

  // Column management
  createCsvColumns(columns: InsertCsvColumn[]): Promise<CsvColumn[]>;
  getCsvColumns(fileId: string): Promise<CsvColumn[]>;

  // Data management
  createCsvData(data: InsertCsvData[]): Promise<CsvData[]>;
  getCsvData(fileId: string, limit?: number, offset?: number, searchTerm?: string): Promise<CsvData[]>;
  updateCsvDataRow(id: string, data: Record<string, any>): Promise<void>;
  deleteCsvDataRow(id: string): Promise<void>;
  getCsvDataCount(fileId: string, searchTerm?: string): Promise<number>;

  // Merge operations
  createMergeOperation(operation: InsertMergeOperation): Promise<MergeOperation>;
  getMergeOperations(): Promise<MergeOperation[]>;

  // Dashboard stats
  getDashboardStats(userId?: string): Promise<DashboardStats>;
}

export class SqliteStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.username, username)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const result = await db.insert(schema.users)
      .values({ ...insertUser, password: hashedPassword })
      .returning();
    return result[0];
  }

  async verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(plainPassword, hashedPassword);
  }

  async createCsvFile(file: InsertCsvFile): Promise<CsvFile> {
    const result = await db.insert(schema.csvFiles).values(file).returning();
    return result[0];
  }

  async getCsvFile(id: string): Promise<CsvFile | undefined> {
    const result = await db.select().from(schema.csvFiles).where(eq(schema.csvFiles.id, id)).limit(1);
    return result[0];
  }

  async getCsvFilesByUser(userId: string, limit = 50, offset = 0): Promise<CsvFile[]> {
    return db.select()
      .from(schema.csvFiles)
      .where(eq(schema.csvFiles.userId, userId))
      .orderBy(desc(schema.csvFiles.uploadedAt))
      .limit(limit)
      .offset(offset);
  }

  async getAllCsvFiles(limit = 50, offset = 0): Promise<CsvFile[]> {
    return db.select()
      .from(schema.csvFiles)
      .orderBy(desc(schema.csvFiles.uploadedAt))
      .limit(limit)
      .offset(offset);
  }

  async updateCsvFileStatus(id: string, status: string, errorMessage?: string): Promise<void> {
    const updateData: any = { status };
    if (status === "completed") {
      updateData.processedAt = new Date();
    }
    if (errorMessage) {
      updateData.errorMessage = errorMessage;
    }
    
    await db.update(schema.csvFiles)
      .set(updateData)
      .where(eq(schema.csvFiles.id, id));
  }

  async deleteCsvFile(id: string): Promise<void> {
    await db.delete(schema.csvFiles).where(eq(schema.csvFiles.id, id));
  }

  async getFileWithStats(id: string): Promise<FileWithStats | undefined> {
    const file = await this.getCsvFile(id);
    if (!file) return undefined;

    const columns = await this.getCsvColumns(id);
    const recordCount = await this.getCsvDataCount(id);

    return {
      ...file,
      columns,
      recordCount
    };
  }

  async createCsvColumns(columns: InsertCsvColumn[]): Promise<CsvColumn[]> {
    const result = await db.insert(schema.csvColumns).values(columns).returning();
    return result;
  }

  async getCsvColumns(fileId: string): Promise<CsvColumn[]> {
    return db.select()
      .from(schema.csvColumns)
      .where(eq(schema.csvColumns.fileId, fileId))
      .orderBy(schema.csvColumns.position);
  }

  async createCsvData(data: InsertCsvData[]): Promise<CsvData[]> {
    const result = await db.insert(schema.csvData).values(data).returning();
    return result;
  }

  async getCsvData(fileId: string, limit = 50, offset = 0, searchTerm?: string): Promise<CsvData[]> {
    let whereConditions = [eq(schema.csvData.fileId, fileId)];
    
    if (searchTerm) {
      whereConditions.push(like(schema.csvData.data, `%${searchTerm}%`));
    }

    return db.select()
      .from(schema.csvData)
      .where(and(...whereConditions))
      .orderBy(schema.csvData.rowIndex)
      .limit(limit)
      .offset(offset);
  }

  async updateCsvDataRow(id: string, data: Record<string, any>): Promise<void> {
    await db.update(schema.csvData)
      .set({
        data: JSON.stringify(data),
        updatedAt: new Date()
      })
      .where(eq(schema.csvData.id, id));
  }

  async deleteCsvDataRow(id: string): Promise<void> {
    await db.delete(schema.csvData).where(eq(schema.csvData.id, id));
  }

  async getCsvDataCount(fileId: string, searchTerm?: string): Promise<number> {
    let whereConditions = [eq(schema.csvData.fileId, fileId)];
    
    if (searchTerm) {
      whereConditions.push(like(schema.csvData.data, `%${searchTerm}%`));
    }

    const result = await db.select({ count: count() })
      .from(schema.csvData)
      .where(and(...whereConditions));
      
    return result[0].count;
  }

  async createMergeOperation(operation: InsertMergeOperation): Promise<MergeOperation> {
    const result = await db.insert(schema.mergeOperations).values(operation).returning();
    return result[0];
  }

  async getMergeOperations(): Promise<MergeOperation[]> {
    return db.select()
      .from(schema.mergeOperations)
      .orderBy(desc(schema.mergeOperations.createdAt));
  }

  async getPublicFiles(): Promise<CsvFile[]> {
    return db.select()
      .from(schema.csvFiles)
      .where(eq(schema.csvFiles.status, "completed"))
      .orderBy(desc(schema.csvFiles.uploadedAt));
  }

  async getDashboardStats(userId?: string): Promise<DashboardStats> {
    const totalFiles = await db.select({ count: count() })
      .from(schema.csvFiles)
      .where(userId ? eq(schema.csvFiles.userId, userId) : undefined as any);
    
    const totalRecords = userId 
      ? await db.select({ count: count() })
          .from(schema.csvData)
          .innerJoin(schema.csvFiles, eq(schema.csvData.fileId, schema.csvFiles.id))
          .where(eq(schema.csvFiles.userId, userId))
      : await db.select({ count: count() }).from(schema.csvData);

    const queueLength = await db.select({ count: count() })
      .from(schema.csvFiles)
      .where(eq(schema.csvFiles.status, "processing"));

    // Calculate storage used (sum of file sizes)
    const storageResult = await db.select({ size: sql<number>`COALESCE(SUM(${schema.csvFiles.fileSize}), 0)` })
      .from(schema.csvFiles)
      .where(userId ? eq(schema.csvFiles.userId, userId) : undefined as any);

    return {
      totalFiles: totalFiles[0].count,
      totalRecords: totalRecords[0].count,
      queueLength: queueLength[0].count,
      storageUsed: storageResult[0].size || 0
    };
  }
}

export const storage = new SqliteStorage();
