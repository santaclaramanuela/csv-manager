import type { Express } from "express";
import { createServer, type Server } from "http";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { initializeDatabase } from "./database/sqlite";
import { authenticateToken, requireRole, optionalAuth, type AuthRequest } from "./middleware/auth";
import { upload } from "./middleware/upload";
import { processCsvFile, validateCsvRow } from "./services/csvProcessor";
import { insertUserSchema, loginSchema } from "@shared/schema";
import { z } from "zod";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

function escapeCsv(v: any) {
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}


export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize database
  await initializeDatabase();

    app.get("/health", (_req, res) => res.json(true));
// Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }

      const user = await storage.createUser(userData);
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role
        },
        token
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const validPassword = await storage.verifyPassword(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role
        },
        token
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: AuthRequest, res) => {
    res.json({ user: req.user });
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const stats = await storage.getDashboardStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // File upload
  app.post("/api/files/upload", authenticateToken, upload.array('files', 10), async (req: AuthRequest, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const uploadedFiles = [];

      for (const file of files) {
        const csvFile = await storage.createCsvFile({
          userId: req.user!.id,
          filename: file.filename,
          originalName: file.originalname,
          fileSize: file.size,
          status: "processing"
        });

        uploadedFiles.push(csvFile);

        // Process file asynchronously
        processCsvFile(csvFile.id, file.path).catch(error => {
          console.error(`Failed to process file ${csvFile.id}:`, error);
        });
      }

      res.json({ files: uploadedFiles });
    } catch (error) {
      res.status(500).json({ message: "File upload failed" });
    }
  });

  // Get user files
  app.get("/api/files", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const files = await storage.getCsvFilesByUser(req.user!.id, limit, offset);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  // Get all files (for merge functionality - public access)
  app.get("/api/files/public", optionalAuth, async (req: AuthRequest, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      // If user is authenticated, show their files. Otherwise show all completed files
      const files = req.user 
        ? await storage.getCsvFilesByUser(req.user.id, limit, offset)
        : await storage.getAllCsvFiles(limit, offset);
      
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  // Get file details
  app.get("/api/files/:id", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const file = await storage.getFileWithStats(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });

// Download CSV: owner or any completed file (public)
app.get("/api/files/:id/download", optionalAuth, async (req: AuthRequest, res) => {
  try {
    const file = await storage.getCsvFile(req.params.id);
    if (!file) return res.status(404).json({ message: "File not found" });

    // Allow if completed (public) or owner/admin
    const isOwner = req.user && (req.user.role === "admin" || file.userId === req.user.id);
    if (file.status !== "completed" && !isOwner) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Stream by reconstructing from DB
    const columns = await storage.getCsvColumns(file.id);
    const total = await storage.getCsvDataCount(file.id);
    const header = columns.map(c => escapeCsv(c.name)).join(",");
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${file.originalName || file.filename || "dataset.csv"}"`);
    res.write(header + "\n");

    const pageSize = 1000;
    for (let offset = 0; offset < total; offset += pageSize) {
      const rows = await storage.getCsvData(file.id, pageSize, offset);
      for (const r of rows as any[]) {
        const data = (r as any).data || {};
        const line = columns.map(c => escapeCsv(data[c.name])).join(",");
        res.write(line + "\n");
      }
    }
    res.end();
  } catch (error) {
    res.status(500).json({ message: "Failed to download file" });
  }
});
      }

      // Check ownership unless user is admin
      if (req.user!.role !== "admin" && file.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(file);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch file details" });
    }
  });

  // Get file data with pagination and search
  app.get("/api/files/:id/data", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const file = await storage.getCsvFile(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Check ownership unless user is admin
      if (req.user!.role !== "admin" && file.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const searchTerm = req.query.search as string;

      const data = await storage.getCsvData(req.params.id, limit, offset, searchTerm);
      const total = await storage.getCsvDataCount(req.params.id, searchTerm);
      const columns = await storage.getCsvColumns(req.params.id);

      res.json({
        data: data.map(row => ({
          id: row.id,
          rowIndex: row.rowIndex,
          ...JSON.parse(row.data as string)
        })),
        total,
        columns
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch file data" });
    }
  });

  // Update row data
  app.put("/api/files/:id/data/:rowId", authenticateToken, requireRole(["admin", "editor"]), async (req: AuthRequest, res) => {
    try {
      const file = await storage.getCsvFile(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Check ownership unless user is admin
      if (req.user!.role !== "admin" && file.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Validate row data
      const validation = await validateCsvRow(req.params.id, req.body);
      if (!validation.valid) {
        return res.status(400).json({ message: "Validation failed", errors: validation.errors });
      }

      await storage.updateCsvDataRow(req.params.rowId, req.body);
      res.json({ message: "Row updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update row" });
    }
  });

  // Delete row
  app.delete("/api/files/:id/data/:rowId", authenticateToken, requireRole(["admin", "editor"]), async (req: AuthRequest, res) => {
    try {
      const file = await storage.getCsvFile(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Check ownership unless user is admin
      if (req.user!.role !== "admin" && file.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      await storage.deleteCsvDataRow(req.params.rowId);
      res.json({ message: "Row deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete row" });
    }
  });

  // Delete file
  app.delete("/api/files/:id", authenticateToken, requireRole(["admin", "editor"]), async (req: AuthRequest, res) => {
    try {
      const file = await storage.getCsvFile(req.params.id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Check ownership unless user is admin
      if (req.user!.role !== "admin" && file.userId !== req.user!.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      await storage.deleteCsvFile(req.params.id);
      res.json({ message: "File deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Merge operations (public access)
  
app.post("/api/merge", optionalAuth, async (req: AuthRequest, res) => {
  try {
    const { sourceFileId, targetFileId, mergeKey, type } = req.body;
    const joinType = (type === "left") ? "left" : "inner";

    if (!sourceFileId || !targetFileId || !mergeKey) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const sourceFile = await storage.getCsvFile(sourceFileId);
    const targetFile = await storage.getCsvFile(targetFileId);
    if (!sourceFile || !targetFile) {
      return res.status(404).json({ message: "One or both files not found" });
    }
    if (sourceFile.status !== "completed" || targetFile.status !== "completed") {
      return res.status(400).json({ message: "Files must be completed before merging" });
    }

    // Load all rows & columns
    const [sourceCols, targetCols] = await Promise.all([
      storage.getCsvColumns(sourceFileId),
      storage.getCsvColumns(targetFileId)
    ]);
    const totalA = await storage.getCsvDataCount(sourceFileId);
    const totalB = await storage.getCsvDataCount(targetFileId);

    function toNameList(cols: any[]) { return cols.map((c:any)=>c.name); }
    const aCols = toNameList(sourceCols);
    const bCols = toNameList(targetCols);

    if (!aCols.includes(mergeKey) || !bCols.includes(mergeKey)) {
      return res.status(400).json({ message: "Merge key must exist in both files" });
    }

    // Build right map
    const pageSize = 5000;
    const rightMap = new Map<string, any[]>();
    for (let offset = 0; offset < totalB; offset += pageSize) {
      const rows = await storage.getCsvData(targetFileId, pageSize, offset);
      for (const r of rows as any[]) {
        const data = (r as any).data || {};
        const k = String(data[mergeKey] ?? "");
        const arr = rightMap.get(k) || [];
        arr.push(data);
        rightMap.set(k, arr);
      }
    }

    const mergedColumns = Array.from(new Set([...aCols, ...bCols.filter(c => c !== mergeKey)]));
    const mergedRows: any[] = [];

    for (let offset = 0; offset < totalA; offset += pageSize) {
      const rows = await storage.getCsvData(sourceFileId, pageSize, offset);
      for (const r of rows as any[]) {
        const data = (r as any).data || {};
        const k = String(data[mergeKey] ?? "");
        const matches = rightMap.get(k);
        if (matches && matches.length) {
          for (const m of matches) {
            mergedRows.push({ ...data, ...Object.fromEntries(Object.entries(m).filter(([c]) => c !== mergeKey)) });
          }
        } else if (joinType === "left") {
          mergedRows.push({ ...data });
        }
      }
    }

    // If no auth or viewer: return as CSV download
    const role = req.user?.role || "viewer";
    if (role === "viewer") {
      const header = mergedColumns.join(",");
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="merge_${Date.now()}.csv"`);
      res.write(header + "\n");
      for (const row of mergedRows) {
        const line = mergedColumns.map(c => escapeCsv(row[c])).join(",");
        res.write(line + "\n");
      }
      return res.end();
    }

    // editor/admin: persist as new file
    const csvTextHeader = mergedColumns.join(",") + "\n";
    let approxSize = csvTextHeader.length;
    for (const row of mergedRows) {
      approxSize += mergedColumns.map(c => String(row[c] ?? "")).join(",").length + 1;
    }

    const now = Date.now();
    const fileRecord = await storage.createCsvFile({
      userId: req.user!.id,
      filename: `merge_${now}.csv`,
      originalName: `merge_${now}.csv`,
      fileSize: approxSize,
      rowCount: mergedRows.length,
      status: "completed",
    } as any);

    // Create columns
    const columnsInsert = mergedColumns.map((name, idx) => ({
      fileId: fileRecord.id,
      name,
      dataType: "text",
      isRequired: false,
      position: idx,
    }));
    await storage.createCsvColumns(columnsInsert as any);

    // Insert data rows
    const dataInsert = mergedRows.map((row, idx) => ({
      fileId: fileRecord.id,
      rowIndex: idx,
      data: row,
    }));
    // insert in chunks to avoid parameter limits
    const chunk = 1000;
    for (let i=0; i<dataInsert.length; i+=chunk) {
      await storage.createCsvData(dataInsert.slice(i, i+chunk) as any);
    }

    return res.json({ message: "Merge completed", resultFileId: fileRecord.id, rows: mergedRows.length });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to perform merge" });
  }
});

      }


      res.json({ mergeOperation });
    } catch (error) {
      res.status(500).json({ message: "Failed to create merge operation" });
    }
  });

  // Get merge operations
  app.get("/api/merge", optionalAuth, async (req: AuthRequest, res) => {
    try {
      const operations = await storage.getMergeOperations();
      res.json(operations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch merge operations" });
    }
  });

  // Get all public CSV files for merge functionality
  app.get("/api/files/public", async (req, res) => {
    try {
      const files = await storage.getPublicFiles();
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch public files" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}