import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import * as schema from "@shared/schema";
import path from "path";
import fs from "fs";

const dbPath = process.env.DATABASE_PATH || "./database.db";
const dbDir = path.dirname(dbPath);

// Ensure database directory exists
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");

export const db = drizzle(sqlite, { schema });

// Initialize database with tables if they don't exist
export async function initializeDatabase() {
  try {
    // Create tables if they don't exist
    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'viewer' CHECK (role IN ('admin', 'editor', 'viewer')),
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE TABLE IF NOT EXISTS csv_files (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        filename TEXT NOT NULL,
        original_name TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        row_count INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing', 'completed', 'error')),
        error_message TEXT,
        uploaded_at INTEGER NOT NULL DEFAULT (unixepoch()),
        processed_at INTEGER
      );

      CREATE TABLE IF NOT EXISTS csv_columns (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        file_id TEXT NOT NULL REFERENCES csv_files(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        data_type TEXT NOT NULL DEFAULT 'text' CHECK (data_type IN ('text', 'number', 'date', 'boolean')),
        is_required INTEGER NOT NULL DEFAULT 0,
        position INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS csv_data (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        file_id TEXT NOT NULL REFERENCES csv_files(id) ON DELETE CASCADE,
        row_index INTEGER NOT NULL,
        data TEXT NOT NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE TABLE IF NOT EXISTS merge_operations (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        source_file_id TEXT NOT NULL REFERENCES csv_files(id) ON DELETE CASCADE,
        target_file_id TEXT NOT NULL REFERENCES csv_files(id) ON DELETE CASCADE,
        merge_key TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'error')),
        result_file_id TEXT REFERENCES csv_files(id) ON DELETE SET NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE INDEX IF NOT EXISTS idx_csv_files_user_id ON csv_files(user_id);
      CREATE INDEX IF NOT EXISTS idx_csv_columns_file_id ON csv_columns(file_id);
      CREATE INDEX IF NOT EXISTS idx_csv_data_file_id ON csv_data(file_id);
      CREATE INDEX IF NOT EXISTS idx_csv_data_row_index ON csv_data(row_index);
    `);

    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Database initialization failed:", error);
    throw error;
  }
}
