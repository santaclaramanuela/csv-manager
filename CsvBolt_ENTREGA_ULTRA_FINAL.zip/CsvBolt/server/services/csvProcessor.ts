import fs from "fs";
import path from "path";
import csv from "csv-parser";
import { storage } from "../storage";
import type { InsertCsvColumn, InsertCsvData } from "@shared/schema";

export interface CsvProcessingResult {
  success: boolean;
  error?: string;
  rowCount?: number;
}

export async function processCsvFile(fileId: string, filePath: string): Promise<CsvProcessingResult> {
  try {
    const file = await storage.getCsvFile(fileId);
    if (!file) {
      throw new Error("File not found");
    }

    // Check if file exists
    if (!fs.existsSync(filePath)) {
      throw new Error("File path does not exist");
    }

    const rows: any[] = [];
    const headers: string[] = [];
    let isFirstRow = true;

    return new Promise((resolve, reject) => {
      const stream = fs.createReadStream(filePath)
        .pipe(csv());

      stream.on('headers', (headerList: string[]) => {
        headers.push(...headerList.map(h => h.trim()));
        console.log("Detected headers:", headers);
      });

      stream.on('data', (data) => {
        if (isFirstRow) {
          isFirstRow = false;
          console.log("First row sample:", data);
        }
        
        // Clean and validate row data
        const cleanedRow: Record<string, any> = {};
        headers.forEach(header => {
          const value = data[header];
          cleanedRow[header] = value != null ? String(value).trim() : "";
        });
        
        rows.push(cleanedRow);
      });

      stream.on('end', async () => {
        try {
          console.log(`Processing ${rows.length} rows with ${headers.length} columns`);

          if (headers.length === 0) {
            throw new Error("No valid headers found in CSV file");
          }

          // Create column definitions with better type inference
          const columns: InsertCsvColumn[] = headers.map((header, index) => {
            const columnData = rows.map(row => row[header]).filter(v => v != null && v !== "");
            
            return {
              fileId,
              name: header,
              dataType: inferDataType(columnData),
              isRequired: false,
              position: index
            };
          });

          console.log("Creating columns:", columns.map(c => `${c.name}:${c.dataType}`));
          await storage.createCsvColumns(columns);

          // Create data rows in batches
          const csvData: InsertCsvData[] = rows.map((row, index) => ({
            fileId,
            rowIndex: index,
            data: JSON.stringify(row)
          }));

          // Process data in smaller batches to avoid memory issues
          const batchSize = 500;
          let processedCount = 0;
          
          for (let i = 0; i < csvData.length; i += batchSize) {
            const batch = csvData.slice(i, i + batchSize);
            await storage.createCsvData(batch);
            processedCount += batch.length;
            console.log(`Processed ${processedCount}/${csvData.length} rows`);
          }

          // Update file status and row count
          await storage.updateCsvFileStatus(fileId, "completed");
          
          // Update row count in the file record
          const db = (storage as any).db;
          if (db) {
            await db.update((storage as any).schema.csvFiles)
              .set({ rowCount: rows.length })
              .where((storage as any).eq((storage as any).schema.csvFiles.id, fileId));
          }

          // Clean up uploaded file
          try {
            fs.unlinkSync(filePath);
            console.log("Cleaned up uploaded file:", filePath);
          } catch (cleanupError) {
            console.warn("Failed to clean up file:", cleanupError);
          }

          console.log(`Successfully processed file ${fileId} with ${rows.length} rows`);
          resolve({
            success: true,
            rowCount: rows.length
          });

        } catch (error) {
          console.error("Error processing CSV data:", error);
          await storage.updateCsvFileStatus(fileId, "error", error instanceof Error ? error.message : "Processing failed");
          reject(error);
        }
      });

      stream.on('error', async (error) => {
        console.error("CSV parsing error:", error);
        await storage.updateCsvFileStatus(fileId, "error", `CSV parsing failed: ${error.message}`);
        reject(error);
      });

      // Handle file read errors
      stream.on('close', () => {
        console.log("CSV processing stream closed");
      });

    });

  } catch (error) {
    console.error("CSV processing setup error:", error);
    await storage.updateCsvFileStatus(fileId, "error", error instanceof Error ? error.message : "Processing failed");
    return {
      success: false,
      error: error instanceof Error ? error.message : "Processing failed"
    };
  }
}

function inferDataType(values: any[]): "text" | "number" | "date" | "boolean" {
  const nonEmptyValues = values
    .filter(v => v != null && v !== "")
    .slice(0, 100); // Sample first 100 values for performance
  
  if (nonEmptyValues.length === 0) return "text";

  // Check for boolean (highest specificity)
  const booleanPattern = /^(true|false|yes|no|y|n|1|0)$/i;
  const booleanValues = nonEmptyValues.filter(v => 
    booleanPattern.test(String(v).trim())
  );
  if (booleanValues.length / nonEmptyValues.length > 0.8) return "boolean";

  // Check for numbers
  const numberValues = nonEmptyValues.filter(v => {
    const str = String(v).trim().replace(/[,$%]/g, ''); // Remove common number formatting
    return !isNaN(Number(str)) && str !== "";
  });
  if (numberValues.length / nonEmptyValues.length > 0.8) return "number";

  // Check for dates (various formats)
  const datePattern = /^\d{4}-\d{2}-\d{2}|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{1,2}\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i;
  const dateValues = nonEmptyValues.filter(v => {
    const str = String(v).trim();
    if (datePattern.test(str)) {
      const date = new Date(str);
      return !isNaN(date.getTime()) && date.getFullYear() > 1900 && date.getFullYear() < 2100;
    }
    return false;
  });
  if (dateValues.length / nonEmptyValues.length > 0.6) return "date";

  return "text";
}

export async function validateCsvRow(fileId: string, rowData: Record<string, any>): Promise<{ valid: boolean; errors: string[] }> {
  const columns = await storage.getCsvColumns(fileId);
  const errors: string[] = [];

  for (const column of columns) {
    const value = rowData[column.name];

    // Check required fields
    if (column.isRequired && (value == null || value === "")) {
      errors.push(`${column.name} is required`);
      continue;
    }

    // Skip validation for empty optional fields
    if (!column.isRequired && (value == null || value === "")) {
      continue;
    }

    // Validate data types
    const stringValue = String(value).trim();
    
    switch (column.dataType) {
      case "number":
        const numberValue = stringValue.replace(/[,$%]/g, '');
        if (isNaN(Number(numberValue)) || numberValue === "") {
          errors.push(`${column.name} must be a valid number`);
        }
        break;
      case "date":
        const date = new Date(stringValue);
        if (isNaN(date.getTime()) || date.getFullYear() < 1900 || date.getFullYear() > 2100) {
          errors.push(`${column.name} must be a valid date`);
        }
        break;
      case "boolean":
        const boolValue = stringValue.toLowerCase();
        if (!["true", "false", "yes", "no", "y", "n", "1", "0"].includes(boolValue)) {
          errors.push(`${column.name} must be a valid boolean value (true/false, yes/no, 1/0)`);
        }
        break;
      case "text":
        // Text validation - could add length checks, pattern matching, etc.
        if (stringValue.length > 10000) {
          errors.push(`${column.name} is too long (maximum 10,000 characters)`);
        }
        break;
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

// Helper function to convert data based on column type
export function convertValue(value: any, dataType: string): any {
  if (value == null || value === "") return null;
  
  const stringValue = String(value).trim();
  
  switch (dataType) {
    case "number":
      const cleanNumber = stringValue.replace(/[,$%]/g, '');
      return Number(cleanNumber);
    case "date":
      return new Date(stringValue).toISOString();
    case "boolean":
      const boolValue = stringValue.toLowerCase();
      return ["true", "yes", "y", "1"].includes(boolValue);
    default:
      return stringValue;
  }
}
