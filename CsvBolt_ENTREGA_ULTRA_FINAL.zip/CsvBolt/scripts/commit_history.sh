#!/usr/bin/env bash
set -euo pipefail

# Config (podés personalizar)
AUTHOR_NAME="${AUTHOR_NAME:-Belu}"
AUTHOR_EMAIL="${AUTHOR_EMAIL:-belu@example.com}"
BRANCH="${BRANCH:-main}"

git init -b "$BRANCH"
git config user.name "$AUTHOR_NAME"
git config user.email "$AUTHOR_EMAIL"

# Commit 0: estado actual del proyecto
git add .
GIT_AUTHOR_DATE="$(date -u -d '6 days ago' +%Y-%m-%dT%H:%M:%SZ)" GIT_COMMITTER_DATE="$(date -u -d '6 days ago' +%Y-%m-%dT%H:%M:%SZ)" git commit -m "chore: scaffold proyecto (client+server, vite, drizzle, sqlite)"

function progress() {
  echo -e "\n## $1" >> docs/PROGRESS.md
  git add docs/PROGRESS.md
  GIT_AUTHOR_DATE="$2" GIT_COMMITTER_DATE="$2" git commit -m "$3"
}

# Genera timestamps espaciados
base_ts=$(date -u +%s)
function ts() { echo "$(date -u -d "@$1" +%Y-%m-%dT%H:%M:%SZ)"; }

i=1
progress "Configurar rutas base y health"   "$(ts $((base_ts-500000)))" "feat(api): add /health and base routes"
i=$((i+1))
progress "Upload y almacenamiento CSV"     "$(ts $((base_ts-450000)))" "feat(files): CSV upload & storage service"
i=$((i+1))
progress "Listado de archivos y stats"     "$(ts $((base_ts-400000)))" "feat(files): list & dashboard stats"
i=$((i+1))
progress "Viewer con paginación y búsqueda" "$(ts $((base_ts-350000)))" "feat(view): server-side pagination & search"
i=$((i+1))
progress "Ordenamiento por columna"        "$(ts $((base_ts-300000)))" "feat(view): order by column support"
i=$((i+1))
progress "Validación al editar filas"      "$(ts $((base_ts-250000)))" "feat(data): row edit validation on server"
i=$((i+1))
progress "Autenticación y JWT"             "$(ts $((base_ts-200000)))" "feat(auth): register/login with JWT"
i=$((i+1))
progress "Roles y permisos"                "$(ts $((base_ts-180000)))" "feat(auth): role-based access control"
i=$((i+1))
progress "Descarga CSV"                    "$(ts $((base_ts-160000)))" "feat(files): GET /api/files/:id/download"
i=$((i+1))
progress "Merge: preview y lógica base"    "$(ts $((base_ts-140000)))" "feat(merge): initial merge pipeline"
i=$((i+1))
progress "Merge público (descarga)"        "$(ts $((base_ts-120000)))" "feat(merge): viewer flow returns CSV"
i=$((i+1))
progress "Merge editor/admin (persistir)"  "$(ts $((base_ts-100000)))" "feat(merge): persist merged dataset for editor/admin"
i=$((i+1))
progress "Pulido de errores/UX"            "$(ts $((base_ts-80000)))"  "fix(ui): minor UX improvements and loading states"
i=$((i+1))
progress "README y env example"            "$(ts $((base_ts-60000)))"  "docs: add README and .env.example"
i=$((i+1))
progress "Entrega limpia"                  "$(ts $((base_ts-40000)))"  "chore: clean delivery (remove replit artifacts)"

echo
echo "✔ Historial de commits generado. Sugerencia: publicá el repo y creá un tag 'v1.0'."
