// backend/src/security/rbac.ts
// Minimal RBAC with viewer allowed to preview/run merges (download-only)
import { Request, Response, NextFunction } from "express";

export type Role = "viewer" | "editor" | "admin";

const abilities: Record<Role, string[]> = {
  viewer: ["files:list", "files:view", "files:download", "merge:preview", "merge:run"],
  editor: ["*"],
  admin: ["*"],
};

export function authorize(...required: string[]) {
  return (req: Request & { user?: any }, res: Response, next: NextFunction) => {
    const role: Role = (req.user?.role ?? "viewer") as Role;
    const perms = abilities[role] || [];
    const ok = required.some((p) => perms.includes(p) || perms.includes("*"));
    if (!ok) return res.status(403).json({ error: "forbidden", need: required, role });
    next();
  };
}
