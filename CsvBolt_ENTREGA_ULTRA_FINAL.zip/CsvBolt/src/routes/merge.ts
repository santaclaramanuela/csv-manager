// backend/src/routes/merge.ts
import { Router } from "express";
import { authorize } from "../security/rbac";
import { doMerge, loadDataset } from "../services/merge";

function escapeCsv(v: any){
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
}

const router = Router();

router.post("/preview", authorize("merge:preview"), async (req, res) => {
  const { leftDatasetId, rightDatasetId, key, type } = req.body as any;
  if (!leftDatasetId || !rightDatasetId || !key) {
    return res.status(400).json({ error: "leftDatasetId, rightDatasetId and key are required" });
  }
  const left = await loadDataset(leftDatasetId);
  const right = await loadDataset(rightDatasetId);
  const result = doMerge(left, right, key, type);
  res.json({ columns: result.columns, rows: result.rows.slice(0, 50), total: result.rows.length });
});

router.post("/run", authorize("merge:run"), async (req: any, res) => {
  const { leftDatasetId, rightDatasetId, key, type } = req.body as any;
  const left = await loadDataset(leftDatasetId);
  const right = await loadDataset(rightDatasetId);
  const result = doMerge(left, right, key, type);

  // viewer: download-only
  if ((req.user?.role ?? "viewer") === "viewer") {
    const header = result.columns.join(",");
    const body = result.rows.map((r) => result.columns.map((c) => escapeCsv(r[c] ?? "")).join(",")).join("\n");
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="merge_${Date.now()}.csv"`);
    return res.send([header, body].join("\n"));
  }

  // editor/admin: persist as dataset
  // Assuming prisma dataset/file/rows models exist
  const dataset = await (await import("../prisma")).prisma.dataset.create({ data: { name: `merge_${Date.now()}` } });
  await (await import("../prisma")).prisma.column.createMany({
    data: result.columns.map((c) => ({ datasetId: dataset.id, name: c, type: "string", required: false, unique: false })),
  });
  await (await import("../prisma")).prisma.row.createMany({
    data: result.rows.map((r) => ({ datasetId: dataset.id, data: r })),
  });
  res.json({ datasetId: dataset.id, rows: result.rows.length });
});

export default router;
