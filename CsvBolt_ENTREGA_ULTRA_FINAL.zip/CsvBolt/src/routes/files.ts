// backend/src/routes/files.ts
import { Router } from "express";
import fs from "fs";
import path from "path";
import { prisma } from "../prisma";
import { authorize } from "../security/rbac";

function escapeCsv(v: any){
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
}

const router = Router();

// Download file or reconstruct from DB
router.get("/:id/download", authorize("files:download"), async (req, res) => {
  const id = req.params.id;
  const file = await prisma.file.findUnique({ where: { id } });
  if (!file) return res.status(404).json({ error: "File not found" });

  if ((file as any).storageName) {
    const filePath = path.join(process.env.UPLOAD_DIR || "uploads", (file as any).storageName);
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${file.originalName || "dataset.csv"}"`);
    return fs.createReadStream(filePath).pipe(res);
  }

  // reconstruct from dataset
  const datasetId = (file as any).datasetId;
  if (!datasetId) return res.status(400).json({ error: "No dataset to export" });
  const cols = await prisma.column.findMany({ where: { datasetId }, orderBy: { id: "asc" } });
  const rows = await prisma.row.findMany({ where: { datasetId }, orderBy: { id: "asc" } });
  const header = cols.map((c) => escapeCsv(c.name)).join(",");
  const body = rows
    .map((r: any) => cols.map((c) => escapeCsv((r as any).data?.[c.name] ?? "")).join(","))
    .join("\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${file.originalName || "dataset.csv"}"`);
  res.send([header, body].join("\n"));
});

// Simple data view with pagination/filter/order via JSON_EXTRACT (SQLite)
router.get("/:id/data", authorize("files:view"), async (req, res) => {
  const id = req.params.id;
  const { limit = 50, offset = 0, search = "", orderBy = "", order = "asc" } = req.query as any;
  const file = await prisma.file.findUnique({ where: { id } });
  if (!file) return res.status(404).json({ error: "File not found" });
  const datasetId = (file as any).datasetId;
  if (!datasetId) return res.json({ rows: [], total: 0 });

  const columns = await prisma.column.findMany({ where: { datasetId }, orderBy: { id: "asc" } });

  // Build SQL using json_extract to support search/order on a specific column
  const columnNames = columns.map((c) => c.name);
  const orderCol = orderBy && columnNames.includes(orderBy) ? orderBy : null;
  const likeClause = search ? `%${search.replace(/%/g, "")}%` : null;

  // Use $queryRaw to leverage json_extract (Prisma client on SQLite)
  const total = Number((await prisma.$queryRawUnsafe(
    `SELECT COUNT(*) as cnt
     FROM Row
     WHERE datasetId = ?
     ${likeClause ? "AND EXISTS (SELECT 1 FROM json_each(data) je WHERE je.value LIKE ?)" : ""}`,
    datasetId, *( [likeClause].filter(Boolean) )
  ) as any[])[0]?.cnt || 0);

  let sql = `SELECT id, data
             FROM Row
             WHERE datasetId = ?
             ${likeClause ? "AND EXISTS (SELECT 1 FROM json_each(data) je WHERE je.value LIKE ?)" : ""} `;
  const params: any[] = [datasetId];
  if (likeClause) params.push(likeClause);
  if (orderCol) {
    sql += `ORDER BY json_extract(data, '$.${orderCol}') ${String(order).toUpperCase()==="DESC"?"DESC":"ASC"} `;
  } else {
    sql += "ORDER BY id ASC ";
  }
  sql += "LIMIT ? OFFSET ?";
  params.push(Number(limit), Number(offset));

  const rows = await prisma.$queryRawUnsafe(sql, ...params) as any[];

  res.json({
    columns: columnNames,
    rows: rows.map((r) => ({ id: r.id, ...r.data })),
    total,
  });
});

export default router;
