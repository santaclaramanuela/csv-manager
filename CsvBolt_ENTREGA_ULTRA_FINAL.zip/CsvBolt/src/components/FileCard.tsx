// frontend/src/components/FileCard.tsx
import { useNavigate } from "react-router-dom";

export default function FileCard({ file, role }: { file: any; role: "viewer" | "editor" | "admin" }) {
  const navigate = useNavigate();
  const base = `/files/${file.id}`;

  return (
    <div className="flex gap-2 items-center">
      <button onClick={() => navigate(base)} aria-label="View" className="btn">👁️ View</button>
      {role !== "viewer" && (
        <button onClick={() => navigate(`${base}/edit`)} aria-label="Edit" className="btn">✏️ Edit</button>
      )}
      <a href={`/api/files/${file.id}/download`} className="btn" aria-label="Download">⬇️ Download</a>
    </div>
  );
}
