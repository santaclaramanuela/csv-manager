// frontend/src/components/DataQualityCard.tsx
export default function DataQualityCard({ issues }: { issues?: {
  nullsByColumn: Record<string, number>;
  typeMismatches: { row: number; column: string; value: any; expected: string }[];
  duplicateRows: number;
}}) {
  if (!issues) return <div className="p-4 border rounded">No se han definido reglas de calidad aún.</div>;
  const nulls = Object.entries(issues.nullsByColumn || {}).filter(([_, v]) => v > 0);
  const mism = issues.typeMismatches?.length ?? 0;
  const dups = issues.duplicateRows ?? 0;
  const noIssues = nulls.length === 0 && mism === 0 && dups === 0;
  if (noIssues) return <div className="p-4 border rounded">No issues found. Your data quality looks great!</div>;
  return (
    <div className="p-4 border rounded space-y-2">
      <div className="font-semibold">Data Quality Issues</div>
      {nulls.length > 0 && (
        <div>
          <div className="font-medium">Nulls by column</div>
          <ul className="list-disc ml-6">
            {nulls.map(([c, v]) => <li key={c}>{c}: {v}</li>)}
          </ul>
        </div>
      )}
      {mism > 0 && <div><span className="font-medium">Type mismatches:</span> {mism}</div>}
      {dups > 0 && <div><span className="font-medium">Duplicate rows:</span> {dups}</div>}
    </div>
  );
}
