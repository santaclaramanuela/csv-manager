// backend/src/services/quality.ts
import { prisma } from "../prisma";

type InferredType = "string" | "number" | "boolean" | "date";

function inferValueType(v: any): InferredType {
  if (v === null || v === undefined || v === "") return "string";
  if (v === "true" || v === "false") return "boolean";
  if (!isNaN(Number(v))) return "number";
  const d = new Date(v);
  if (!isNaN(d.getTime())) return "date";
  return "string";
}

export async function analyzeQuality(datasetId: string) {
  const cols = await prisma.column.findMany({ where: { datasetId }, orderBy: { id: "asc" } });
  const rows = await prisma.row.findMany({ where: { datasetId }, orderBy: { id: "asc" } }) as any[];
  const colNames = cols.map((c) => c.name);
  const inferred: Record<string, InferredType> = {};
  for (const c of colNames) {
    // infer from first non-empty value
    let type: InferredType = "string";
    for (const r of rows) {
      const v = (r as any).data?.[c];
      if (v !== null && v !== undefined && v !== "") { type = inferValueType(v); break; }
    }
    inferred[c] = type;
  }

  const issues = {
    nullsByColumn: Object.fromEntries(colNames.map((c) => [c, 0])) as Record<string, number>,
    typeMismatches: [] as { row: number; column: string; value: any; expected: string }[],
    duplicateRows: 0,
  };

  const seen = new Set<string>();
  rows.forEach((r, idx) => {
    const data: any = (r as any).data || {};
    const key = JSON.stringify(data);
    if (seen.has(key)) issues.duplicateRows++;
    else seen.add(key);
    colNames.forEach((c) => {
      const v = data[c];
      if (v === null || v === undefined || v === "") issues.nullsByColumn[c]++;
      else {
        const t = inferValueType(v);
        if (t !== inferred[c]) issues.typeMismatches.push({ row: idx + 1, column: c, value: v, expected: inferred[c] });
      }
    });
  });

  // persist in dataset.quality (JSON)
  await prisma.dataset.update({ where: { id: datasetId }, data: { quality: issues as any } });
  return issues;
}
