// backend/src/services/merge.ts
import { prisma } from "../prisma";

export type MergeType = "inner" | "left";

export async function loadDataset(datasetId: string) {
  const cols = await prisma.column.findMany({ where: { datasetId }, orderBy: { id: "asc" } });
  const rows = await prisma.row.findMany({ where: { datasetId }, orderBy: { id: "asc" } }) as any[];
  const columns = cols.map((c) => c.name);
  const data = rows.map((r) => r.data as Record<string, any>);
  return { columns, data };
}

export function doMerge(
  left: { columns: string[]; data: Record<string, any>[] },
  right: { columns: string[]; data: Record<string, any>[] },
  key: string,
  type: MergeType = "inner"
) {
  const columns = Array.from(new Set([
    ...left.columns,
    ...right.columns.filter((c) => c !== key), // avoid duplicated key
  ]));

  const rightMap = new Map<string, Record<string, any>[]>();
  for (const r of right.data) {
    const k = String(r[key] ?? "");
    const arr = rightMap.get(k) || [];
    arr.push(r);
    rightMap.set(k, arr);
  }

  const rows: Record<string, any>[] = [];
  for (const l of left.data) {
    const k = String(l[key] ?? "");
    const matches = rightMap.get(k);
    if (matches && matches.length) {
      for (const rr of matches) {
        rows.push({ ...l, ...Object.fromEntries(Object.entries(rr).filter(([c]) => c !== key)) });
      }
    } else if (type === "left") {
      rows.push({ ...l });
    }
  }
  return { columns, rows };
}
