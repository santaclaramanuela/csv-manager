// frontend/src/pages/MergeFiles.tsx
import { useState } from "react";
import { apiFetch } from "../api/http";

export default function MergeFiles({ user }: { user: { role: "viewer" | "editor" | "admin" } }) {
  const [leftId, setLeftId] = useState("");
  const [rightId, setRightId] = useState("");
  const [key, setKey] = useState("");
  const [type, setType] = useState<"inner"|"left">("inner");
  const [preview, setPreview] = useState<{columns:string[]; rows:any[]; total:number} | null>(null);
  const canUse = ["viewer", "editor", "admin"].includes(user?.role);
  if (!canUse) return <div className="p-6">Access denied.</div>;

  async function doPreview() {
    const data = await apiFetch("/api/merge/preview", {
      method: "POST",
      body: JSON.stringify({ leftDatasetId: leftId, rightDatasetId: rightId, key, type }),
    });
    setPreview(data);
  }

  async function runMerge() {
    const res = await apiFetch("/api/merge/run", {
      method: "POST",
      body: JSON.stringify({ leftDatasetId: leftId, rightDatasetId: rightId, key, type }),
    });
    // If viewer, the API responds with a CSV file (stream). The wrapper returns Response when not JSON.
    if (res && (res as any).body) {
      // trigger download
      const r = res as Response;
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `merge_${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      alert("Merge saved with datasetId: " + (res as any).datasetId);
    }
  }

  return (
    <div className="p-4 space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <input placeholder="Left datasetId" value={leftId} onChange={(e)=>setLeftId(e.target.value)} />
        <input placeholder="Right datasetId" value={rightId} onChange={(e)=>setRightId(e.target.value)} />
        <input placeholder="Join key (column name)" value={key} onChange={(e)=>setKey(e.target.value)} />
        <select value={type} onChange={(e)=>setType(e.target.value as any)}>
          <option value="inner">inner</option>
          <option value="left">left</option>
        </select>
      </div>
      <div className="flex gap-2">
        <button onClick={doPreview} className="btn">Preview</button>
        <button onClick={runMerge} className="btn">Run</button>
      </div>

      {preview && (
        <div className="border rounded p-2">
          <div className="text-sm text-gray-500 mb-2">Previewing {preview.total} rows (showing first {preview.rows.length})</div>
          <div className="overflow-auto">
            <table className="min-w-full text-sm">
              <thead><tr>{preview.columns.map(c=> <th key={c} className="text-left pr-4">{c}</th>)}</tr></thead>
              <tbody>
                {preview.rows.map((r,i)=> (
                  <tr key={i}>{preview.columns.map(c=> <td key={c} className="pr-4">{String(r[c]??"")}</td>)}</tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
