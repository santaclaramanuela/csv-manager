// frontend/src/pages/DatasetView.tsx
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { apiFetch } from "../api/http";

export default function DatasetView() {
  const { id } = useParams();
  const [rows, setRows] = useState<any[]>([]);
  const [columns, setColumns] = useState<string[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(50);
  const [search, setSearch] = useState("");
  const [orderBy, setOrderBy] = useState("");
  const [order, setOrder] = useState<"asc" | "desc">("asc");

  async function load() {
    setLoading(true);
    try {
      const q = new URLSearchParams({
        limit: String(pageSize),
        offset: String(page * pageSize),
        search,
        orderBy,
        order,
      });
      const data = await apiFetch(`/api/files/${id}/data?` + q.toString());
      setRows(data.rows);
      setColumns(data.columns);
      setTotal(data.total);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [id, page, pageSize, search, orderBy, order]);

  return (
    <div className="p-4">
      <div className="flex gap-2 mb-2">
        <input placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select value={orderBy} onChange={(e) => setOrderBy(e.target.value)}>
          <option value="">(no order)</option>
          {columns.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={order} onChange={(e) => setOrder(e.target.value as any)}>
          <option value="asc">asc</option>
          <option value="desc">desc</option>
        </select>
      </div>
      <div className="text-sm text-gray-500 mb-2">Total rows: {total}</div>
      <div className="overflow-auto border rounded p-2">
        <table className="min-w-full text-sm">
          <thead>
            <tr>{columns.map((c) => <th key={c} className="text-left pr-4">{c}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                {columns.map((c) => <td key={c} className="pr-4">{String(r[c] ?? "")}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center gap-2 mt-2">
        <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}>Prev</button>
        <span>Page {page + 1}</span>
        <button onClick={() => setPage((p) => (p + 1))} disabled={(page + 1) * pageSize >= total}>Next</button>
      </div>
    </div>
  );
}
