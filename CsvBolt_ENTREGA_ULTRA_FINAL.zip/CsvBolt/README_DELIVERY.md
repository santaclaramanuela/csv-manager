# CsvBolt — Entrega limpia (para corrección)

Incluye:
- **Descarga de CSV**: `GET /api/files/:id/download` (si el archivo está *completed* o sos dueño/admin).
- **Merge funcional** en `POST /api/merge`:
  - `viewer` (o sin login): descarga directa del CSV resultante.
  - `editor/admin`: crea un nuevo archivo (dataset) con columnas y filas.
- `GET /api/files/:id/data` ya soporta **limit/offset/search**.
- Roles: `viewer`, `editor`, `admin` (middleware existente).

## Cómo correr
1. `npm install`
2. `npm run dev` (servidor + Vite según tu setup)
3. Crear `.env` desde `.env.example` y completar `JWT_SECRET`

## Probar rápido
- Subí dos CSV → Merge (página *Merge*): ejecuta y descargá el resultado (sin login).
- Con login `editor`/`admin`: el merge devuelve `resultFileId` (dataset persistido).
- En *My Files* podés usar **Download** (endpoint del server).

## Notas
- Se eliminaron carpetas/archivos de entorno (`.git`, `attached_assets`, `.local`, etc.) para bajar el peso del zip.
