import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, real, blob } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = sqliteTable("users", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["admin", "editor", "viewer"] }).default("viewer").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
});

export const csvFiles = sqliteTable("csv_files", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  userId: text("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  fileSize: integer("file_size").notNull(),
  rowCount: integer("row_count").default(0).notNull(),
  status: text("status", { enum: ["processing", "completed", "error"] }).default("processing").notNull(),
  errorMessage: text("error_message"),
  uploadedAt: integer("uploaded_at", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
  processedAt: integer("processed_at", { mode: "timestamp" }),
});

export const csvColumns = sqliteTable("csv_columns", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  fileId: text("file_id").references(() => csvFiles.id, { onDelete: "cascade" }).notNull(),
  name: text("name").notNull(),
  dataType: text("data_type", { enum: ["text", "number", "date", "boolean"] }).default("text").notNull(),
  isRequired: integer("is_required", { mode: "boolean" }).default(false).notNull(),
  position: integer("position").notNull(),
});

export const csvData = sqliteTable("csv_data", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  fileId: text("file_id").references(() => csvFiles.id, { onDelete: "cascade" }).notNull(),
  rowIndex: integer("row_index").notNull(),
  data: text("data", { mode: "json" }).notNull(), // JSON object with column data
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
});

export const mergeOperations = sqliteTable("merge_operations", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  sourceFileId: text("source_file_id").references(() => csvFiles.id, { onDelete: "cascade" }).notNull(),
  targetFileId: text("target_file_id").references(() => csvFiles.id, { onDelete: "cascade" }).notNull(),
  mergeKey: text("merge_key").notNull(), // Column to merge on
  status: text("status", { enum: ["pending", "completed", "error"] }).default("pending").notNull(),
  resultFileId: text("result_file_id").references(() => csvFiles.id, { onDelete: "set null" }),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`).notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email address"),
});

export const insertCsvFileSchema = createInsertSchema(csvFiles).omit({
  id: true,
  uploadedAt: true,
  processedAt: true,
});

export const insertCsvColumnSchema = createInsertSchema(csvColumns).omit({
  id: true,
});

export const insertCsvDataSchema = createInsertSchema(csvData).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMergeOperationSchema = createInsertSchema(mergeOperations).omit({
  id: true,
  createdAt: true,
});

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCsvFile = z.infer<typeof insertCsvFileSchema>;
export type CsvFile = typeof csvFiles.$inferSelect;
export type InsertCsvColumn = z.infer<typeof insertCsvColumnSchema>;
export type CsvColumn = typeof csvColumns.$inferSelect;
export type InsertCsvData = z.infer<typeof insertCsvDataSchema>;
export type CsvData = typeof csvData.$inferSelect;
export type InsertMergeOperation = z.infer<typeof insertMergeOperationSchema>;
export type MergeOperation = typeof mergeOperations.$inferSelect;
export type LoginCredentials = z.infer<typeof loginSchema>;

// Additional types for API responses
export type FileWithStats = CsvFile & {
  columns: CsvColumn[];
  recordCount: number;
};

export type DashboardStats = {
  totalFiles: number;
  totalRecords: number;
  queueLength: number;
  storageUsed: number;
};

export type TableRow = {
  id: string;
  [key: string]: any;
};
