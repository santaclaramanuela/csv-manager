export interface User {
  id: string;
  username: string;
  email: string;
  role: "admin" | "editor" | "viewer";
}

export interface CsvFile {
  id: string;
  userId: string;
  filename: string;
  originalName: string;
  fileSize: number;
  rowCount: number;
  status: "processing" | "completed" | "error";
  errorMessage?: string;
  uploadedAt: Date;
  processedAt?: Date;
}

export interface CsvColumn {
  id: string;
  fileId: string;
  name: string;
  dataType: "text" | "number" | "date" | "boolean";
  isRequired: boolean;
  position: number;
}

export interface TableRow {
  id: string;
  rowIndex: number;
  [key: string]: any;
}

export interface DashboardStats {
  totalFiles: number;
  totalRecords: number;
  queueLength: number;
  storageUsed: number;
}

export interface FileWithStats extends CsvFile {
  columns: CsvColumn[];
  recordCount: number;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  role?: "admin" | "editor" | "viewer";
}

export interface ApiResponse<T = any> {
  data?: T;
  message?: string;
  errors?: string[];
}
