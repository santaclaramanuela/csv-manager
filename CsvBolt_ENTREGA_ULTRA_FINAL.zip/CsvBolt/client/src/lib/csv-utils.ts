export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat().format(num);
}

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString();
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "completed":
      return "text-green-800 bg-green-100";
    case "processing":
      return "text-yellow-800 bg-yellow-100";
    case "error":
      return "text-red-800 bg-red-100";
    default:
      return "text-gray-800 bg-gray-100";
  }
}

export function getStatusIcon(status: string): string {
  switch (status) {
    case "completed":
      return "fas fa-check-circle";
    case "processing":
      return "fas fa-clock";
    case "error":
      return "fas fa-exclamation-triangle";
    default:
      return "fas fa-file";
  }
}

export function validateCsvFile(file: File): { valid: boolean; error?: string } {
  if (!file.name.toLowerCase().endsWith('.csv')) {
    return { valid: false, error: "Only CSV files are allowed" };
  }
  
  if (file.size > 10 * 1024 * 1024) {
    return { valid: false, error: "File size must be less than 10MB" };
  }
  
  return { valid: true };
}

export function downloadCsv(data: any[], filename: string): void {
  if (data.length === 0) return;
  
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(header => {
      const value = row[header];
      // Escape quotes and wrap in quotes if contains comma
      if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
        return `"${value.replace(/"/g, '""')}"`;
      }
      return value;
    }).join(','))
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  window.URL.revokeObjectURL(url);
}
