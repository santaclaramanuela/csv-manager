import { apiRequest } from "./queryClient";
import type { User, LoginCredentials, RegisterData } from "../types";

const TOKEN_KEY = "auth_token";

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setAuthToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeAuthToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

export async function loginUser(credentials: LoginCredentials): Promise<{ user: User; token: string }> {
  const response = await apiRequest("POST", "/api/auth/login", credentials);
  const data = await response.json();
  setAuthToken(data.token);
  return data;
}

export async function registerUser(userDatos: RegistrarseDatos): Promise<{ user: User; token: string }> {
  const response = await apiRequest("POST", "/api/auth/register", userDatos);
  const data = await response.json();
  setAuthToken(data.token);
  return data;
}

export async function getCurrentUser(): Promise<User | null> {
  const token = getAuthToken();
  if (!token) return null;

  try {
    const response = await fetch("/api/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      removeAuthToken();
      return null;
    }

    const data = await response.json();
    return data.user;
  } catch (error) {
    removeAuthToken();
    return null;
  }
}

export function logout(): void {
  removeAuthToken();
  window.location.href = "/login";
}
