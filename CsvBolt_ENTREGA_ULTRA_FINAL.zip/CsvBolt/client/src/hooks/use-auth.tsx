import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCurrentUser, loginUser, registerUser, logout as authLogout } from "../lib/auth";
import type { User, LoginCredentials, RegisterData } from "../types";
import { useToast } from "./use-toast";

interface AuthContextType {
  user: User | null;
  isCargando: boolean;
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (userDatos: RegistrarseDatos) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: currentUser, isCargando } = useQuery({
    queryKey: ["auth", "me"],
    queryFn: getCurrentUser,
    retry: false,
    staleTime: Infinity,
  });

  const loginMutation = useMutation({
    mutationFn: loginUser,
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.setQueryDatos(["auth", "me"], data.user);
      toast({
        title: "Iniciar sesión successful",
        description: "Welcome back!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Iniciar sesión failed",
        description: error.message || "Credenciales inválidas",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: registerUser,
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.setQueryDatos(["auth", "me"], data.user);
      toast({
        title: "Registro exitoso",
        description: "Welcome to CSVBolt!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "Registration failed",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (currentUser) {
      setUser(currentUser);
    }
  }, [currentUser]);

  const login = async (credentials: Iniciar sesiónCredentials) => {
    await loginMutation.mutateAsync(credentials);
  };

  const register = async (userDatos: RegistrarseDatos) => {
    await registerMutation.mutateAsync(userDatos);
  };

  const logout = () => {
    setUser(null);
    queryClient.clear();
    authCerrar sesión();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isCargando,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
