import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "../ui/card";
import { Skeleton } from "../ui/skeleton";
import { formatFileSize, formatNumber } from "../../lib/csv-utils";
import { Database, Files, Clock, HardDrive, TrendingUp } from "lucide-react";
import type { DashboardStats } from "../../types";

export function StatsCards() {
  const { data: stats, isCargando } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isCargando) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="p-6">
            <Skeleton className="h-16 w-full" />
          </Card>
        ))}
      </div>
    );
  }

  if (!stats) {
    return null;
  }

  const statCards = [
    {
      title: "Total Archivos",
      value: stats.totalArchivos.toString(),
      icon: Archivos,
      color: "text-blue-600 bg-blue-100 dark:bg-blue-900/20",
      trend: "+12%",
      description: "vs last month",
    },
    {
      title: "Total Records",
      value: formatNumber(stats.totalRecords),
      icon: Datosbase,
      color: "text-green-600 bg-green-100 dark:bg-green-900/20",
      trend: "+8.2%",
      description: "new records",
    },
    {
      title: "Procesando Queue",
      value: stats.queueLength.toString(),
      icon: Clock,
      color: "text-orange-600 bg-orange-100 dark:bg-orange-900/20",
      status: stats.queueLength === 0 ? "All systems operational" : `${stats.queueLength} files in queue`,
    },
    {
      title: "Storage Used",
      value: formatFileTamaño(stats.storageUsed),
      icon: HardDrive,
      color: "text-purple-600 bg-purple-100 dark:bg-purple-900/20",
      percentage: Math.round((stats.storageUsed / (5 * 1024 * 1024 * 1024)) * 100), // Assuming 5GB limit
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((card, index) => (
        <Card key={index} className="p-6" data-testid={`card-stats-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
              <p className="text-3xl font-bold text-foreground" data-testid={`text-${card.title.toLowerCase().replace(/\s+/g, "-")}-value`}>
                {card.value}
              </p>
            </div>
            <div className={`p-3 rounded-lg ${card.color}`}>
              <card.icon size={24} />
            </div>
          </div>
          <div className="mt-4">
            {card.trend && (
              <div className="flex items-center text-sm">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-green-600 font-medium">{card.trend}</span>
                <span className="text-muted-foreground ml-1">{card.description}</span>
              </div>
            )}
            {card.status && (
              <div className="flex items-center text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <span className="text-muted-foreground">{card.status}</span>
              </div>
            )}
            {card.percentage !== undefined && (
              <div>
                <div className="w-full bg-muted rounded-full h-2 mt-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min(card.percentage, 100)}%` }}
                  ></div>
                </div>
                <span className="text-sm text-muted-foreground mt-1">
                  {card.percentage}% of 5GB limit
                </span>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}
