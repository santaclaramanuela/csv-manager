import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "../ui/card";
import { Button } from "../ui/button";
import { Progress } from "../ui/progress";
import { Alert, AlertDescription } from "../ui/alert";
import { useToast } from "../../hooks/use-toast";
import { validateCsvFile } from "../../lib/csv-utils";
import { getAuthToken } from "../../lib/auth";
import { CloudUpload, AlertTriangle } from "lucide-react";

interface UploadProgress {
  fileName: string;
  progress: number;
  status: "uploading" | "completed" | "error";
  error?: string;
}

export function FileUpload() {
  const [uploadProgress, setUploadProgress] = useState<UploadProgress[]>([]);
  const [isSubiring, setIsSubiring] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (files: File[]) => {
      const formDatos = new FormDatos();
      files.forEach(file => formDatos.append('files', file));

      const token = getAuthToken();
      const response = await fetch('/api/files/upload', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formDatos,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Subir failed');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Subir successful",
        description: "Your files have been uploaded and are being processed",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Subir failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback(async (acceptedArchivos: File[]) => {
    const validArchivos: File[] = [];
    const errors: string[] = [];

    // Validate files
    acceptedArchivos.forEach(file => {
      const validation = validateCsvFile(file);
      if (validation.valid) {
        validArchivos.push(file);
      } else {
        errors.push(`${file.name}: ${validation.error}`);
      }
    });

    if (errors.length > 0) {
      toast({
        title: "Some files were rejected",
        description: errors.join(", "),
        variant: "destructive",
      });
    }

    if (validArchivos.length === 0) return;

    setIsSubiring(true);
    setSubirProgress(
      validArchivos.map(file => ({
        fileNombre: file.name,
        progress: 0,
        status: "uploading",
      }))
    );

    try {
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setSubirProgress(prev =>
          prev.map(item => ({
            ...item,
            progress: Math.min(item.progress + Math.random() * 20, 90),
          }))
        );
      }, 500);

      await uploadMutation.mutateAsync(validArchivos);

      clearInterval(progressInterval);
      
      setSubirProgress(prev =>
        prev.map(item => ({
          ...item,
          progress: 100,
          status: "completed",
        }))
      );

      setTimeout(() => {
        setSubirProgress([]);
        setIsSubiring(false);
      }, 2000);

    } catch (error) {
      setSubirProgress(prev =>
        prev.map(item => ({
          ...item,
          status: "error",
          error: error instanceof Error ? error.message : "Subir failed",
        }))
      );
      setIsSubiring(false);
    }
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
    },
    multiple: true,
    maxArchivos: 10,
  });

  return (
    <Card className="p-8 mb-8" data-testid="card-file-upload">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Subir CSV Archivos</h2>
        <p className="text-muted-foreground mb-8">
          Drag and drop your CSV files or click to browse
        </p>

        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-xl p-12 cursor-pointer transition-colors ${
            isDragActive
              ? "border-primary bg-primary/5"
              : "border-border hover:border-primary"
          }`}
          data-testid="dropzone-upload"
        >
          <input {...getInputProps()} data-testid="input-file-upload" />
          <div className="flex flex-col items-center">
            <div className="bg-primary/10 text-primary p-4 rounded-full mb-4">
              <CloudUpload size={32} />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              {isDragActive ? "Drop your CSV files here" : "Drop your CSV files here"}
            </h3>
            <p className="text-muted-foreground mb-4">or</p>
            <Button type="button" className="mb-4" data-testid="button-browse-files">
              Browse Archivos
            </Button>
            <p className="text-sm text-muted-foreground">
              Supports multiple files • Max 10MB per file
            </p>
          </div>
        </div>

        {/* Subir Progress */}
        {uploadProgress.length > 0 && (
          <div className="mt-6 space-y-4" data-testid="container-upload-progress">
            <h4 className="text-lg font-medium">Subir Progress</h4>
            {uploadProgress.map((file, index) => (
              <div key={index} className="bg-muted rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">
                    {file.fileNombre}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {file.status === "completed" ? "Completado" : `${Math.round(file.progress)}%`}
                  </span>
                </div>
                <Progress
                  value={file.progress}
                  className={`h-2 ${
                    file.status === "error" ? "bg-red-100" : ""
                  }`}
                  data-testid={`progress-${index}`}
                />
                {file.error && (
                  <Alert className="mt-2 border-destructive/20 bg-destructive/5">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                    <AlertDescription className="text-destructive">
                      {file.error}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}
