import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Badge } from "../ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { useToast } from "../../hooks/use-toast";
import { formatFileSize, formatDate, getStatusColor, downloadCsv } from "../../lib/csv-utils";
import { getAuthToken } from "../../lib/auth";
import { Search, Eye, Edit, Download, Trash2, RefreshCw, AlertTriangle, FileText } from "lucide-react";
import type { CsvFile } from "../../types";

export function FilesList() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: files, isCargando } = useQuery<CsvFile[]>({
    queryKey: ["/api/files"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const token = getAuthToken();
      const response = await fetch(`/api/files/${fileId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Eliminar failed');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Archivo eliminado",
        description: "El archivo fue eliminado correctamente",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Eliminar failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleEliminar = (fileId: string) => {
    if (window.confirm("¿Seguro que querés eliminar este archivo? Esta acción no se puede deshacer.")) {
      deleteMutation.mutate(fileId);
    }
  };

  const handleDescargar = async (file: CsvFile) => {
    try {
      const token = getAuthToken();
      const response = await fetch(`/api/files/${file.id}/data?limit=10000`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Falló to fetch file data');
      }

      const { data } = await response.json();
      
      if (data && data.length > 0) {
        // Remove internal fields (id, rowIndex) before download
        const cleanDatos = data.map(({ id, rowIndex, ...rest }: any) => rest);
        downloadCsv(cleanDatos, file.originalNombre);
        toast({
          title: "Descargar successful",
          description: `Descargared ${file.originalNombre}`,
        });
      } else {
        toast({
          title: "Descargar failed",
          description: "Sin datos available to download",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Descargar failed",
        description: "Falló to download file",
        variant: "destructive",
      });
    }
  };

  const filteredArchivos = files?.filter(file => {
    const matchesBuscar = file.originalNombre.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesEstado = statusFilter === "all" || file.status === statusFilter;
    return matchesBuscar && matchesEstado;
  }) || [];

  const getEstadoIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <FileText className="h-4 w-4 text-green-600" />;
      case "processing":
        return <RefreshCw className="h-4 w-4 text-yellow-600 animate-spin" />;
      case "error":
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <FileText className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <Card className="mb-8" data-testid="card-files-list">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle>Recent Archivos</CardTitle>
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar archivos..."
                className="pl-10 w-64"
                value={searchTerm}
                onChange={(e) => setBuscarTerm(e.target.value)}
                data-testid="input-files-search"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40" data-testid="select-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Archivos</SelectItem>
                <SelectItem value="processing">Procesando</SelectItem>
                <SelectItem value="completed">Completado</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {isCargando ? (
          <div className="p-6">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 mb-4">
                <Skeleton className="h-12 w-12 rounded" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>File Nombre</TableHead>
                <TableHead>Tamaño</TableHead>
                <TableHead>Records</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Subired</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredArchivos.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    {searchTerm || statusFilter !== "all" 
                      ? "No files match your search criteria" 
                      : "No files uploaded yet"
                    }
                  </TableCell>
                </TableRow>
              ) : (
                filteredArchivos.map((file) => (
                  <TableRow key={file.id} className="hover:bg-muted/50" data-testid={`row-file-${file.id}`}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-lg ${getStatusColor(file.status)}`}>
                          {getEstadoIcon(file.status)}
                        </div>
                        <div>
                          <div className="font-medium text-foreground" data-testid={`text-filename-${file.id}`}>
                            {file.originalNombre}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Updated {formatDate(file.uploadedAt)}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-foreground" data-testid={`text-filesize-${file.id}`}>
                      {formatFileTamaño(file.fileTamaño)}
                    </TableCell>
                    <TableCell className="text-foreground" data-testid={`text-records-${file.id}`}>
                      {file.rowCount.toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={file.status === "completed" ? "default" : file.status === "error" ? "destructive" : "secondary"}
                        data-testid={`badge-status-${file.id}`}
                      >
                        {file.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground" data-testid={`text-uploaded-${file.id}`}>
                      {formatDate(file.uploadedAt)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {file.status === "completed" && (
                          <>
                            <Link href={`/files/${file.id}`}>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-primary hover:text-primary"
                                data-testid={`button-view-${file.id}`}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-muted-foreground hover:text-foreground"
                              onClick={() => handleDescargar(file)}
                              data-testid={`button-download-${file.id}`}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => handleEliminar(file.id)}
                          data-testid={`button-delete-${file.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
