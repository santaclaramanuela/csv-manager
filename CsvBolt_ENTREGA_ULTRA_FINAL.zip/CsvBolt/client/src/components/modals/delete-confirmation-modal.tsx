import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { Button } from "../ui/button";
import { AlertTriangle, Loader2 } from "lucide-react";
import { useState } from "react";

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void> | void;
  title?: string;
  description?: string;
  confirmText?: string;
  cancelText?: string;
  variant?: "default" | "destructive";
}

export function EliminarConfirmationModal({
  isAbrir,
  onClose,
  onConfirm,
  title = "Confirm Deletion",
  description = "Are you sure you want to delete this item? This action cannot be undone.",
  confirmText = "Eliminar",
  cancelText = "Cancelarar",
  variant = "destructive",
}: EliminarConfirmationModalProps) {
  const [isCargando, setIsCargando] = useState(false);

  const handleConfirm = async () => {
    setIsCargando(true);
    try {
      await onConfirm();
    } finally {
      setIsCargando(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="modal-delete-confirmation">
        <DialogHeader>
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-full ${
              variant === "destructive" 
                ? "bg-destructive/10 text-destructive" 
                : "bg-yellow-100 text-yellow-600 dark:bg-yellow-900/20"
            }`}>
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div>
              <DialogTitle className="text-left">{title}</DialogTitle>
            </div>
          </div>
          <DialogDescription className="text-left mt-2">
            {description}
          </DialogDescription>
        </DialogHeader>

        <div className="flex justify-end space-x-3 mt-6">
          <Button 
            variant="outline" 
            onClick={onClose}
            disabled={isCargando}
            data-testid="button-cancel-delete"
          >
            {cancelText}
          </Button>
          <Button 
            variant={variant}
            onClick={handleConfirm}
            disabled={isCargando}
            data-testid="button-confirm-delete"
          >
            {isCargando && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {confirmText}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
