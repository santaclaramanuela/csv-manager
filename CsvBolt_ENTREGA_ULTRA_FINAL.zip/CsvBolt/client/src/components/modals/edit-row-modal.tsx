import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Switch } from "../ui/switch";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { useToast } from "../../hooks/use-toast";
import { getAuthToken } from "../../lib/auth";
import { Loader2 } from "lucide-react";
import type { CsvColumn } from "../../types";
import type { TableRow } from "@shared/schema";

interface EditRowModalProps {
  row: TableRow;
  columns: CsvColumn[];
  fileId: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function EditarRowModal({
  row,
  columns,
  fileId,
  isAbrir,
  onClose,
  onSuccess,
}: EditarRowModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isNewRow = row.id === "new";

  // Create dynamic schema based on columns
  const createSchema = () => {
    const schemaFields: Record<string, z.ZodTypeAny> = {};
    
    columns.forEach(column => {
      let field: z.ZodTypeAny;
      
      switch (column.dataType) {
        case "number":
          field = z.coerce.number().optional();
          if (column.isRequired) {
            field = z.coerce.number({ required_error: `${column.name} is required` });
          }
          break;
        case "date":
          field = z.string().optional();
          if (column.isRequired) {
            field = z.string().min(1, `${column.name} is required`);
          }
          break;
        case "boolean":
          field = z.boolean().optional();
          break;
        default:
          field = z.string().optional();
          if (column.isRequired) {
            field = z.string().min(1, `${column.name} is required`);
          }
      }
      
      schemaFields[column.name] = field;
    });
    
    return z.object(schemaFields);
  };

  const form = useForm({
    resolver: zodResolver(createSchema()),
    defaultValues: isNewRow ? {} : { ...row },
  });

  const mutation = useMutation({
    mutationFn: async (data: Record<string, any>) => {
      const token = getAuthToken();
      const url = isNewRow 
        ? `/api/files/${fileId}/data`
        : `/api/files/${fileId}/data/${row.id}`;
      
      const response = await fetch(url, {
        method: isNewRow ? 'POST' : 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Falló to save row');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files", fileId, "data"] });
      toast({
        title: isNewRow ? "Row created" : "Fila actualizada",
        description: `Row has been successfully ${isNewRow ? "created" : "updated"}`,
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Guardar failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: Record<string, any>) => {
    // Clean up data - remove empty strings for optional fields
    const cleanedDatos: Record<string, any> = {};
    columns.forEach(column => {
      const value = data[column.name];
      if (value !== "" && value !== undefined && value !== null) {
        cleanedDatos[column.name] = value;
      } else if (column.isRequired) {
        cleanedDatos[column.name] = value;
      }
    });
    
    mutation.mutate(cleanedDatos);
  };

  const renderField = (column: CsvColumn) => {
    const fieldNombre = column.name;
    
    return (
      <FormField
        key={column.id}
        control={form.control}
        name={fieldName as any}
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center space-x-1">
              <span>{column.name}</span>
              {column.isRequired && <span className="text-destructive">*</span>}
              <span className="text-xs text-muted-foreground">({column.dataType})</span>
            </FormLabel>
            <FormControl>
              {column.dataType === "boolean" ? (
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={field.value || false}
                    onCheckedChange={field.onChange}
                    data-testid={`switch-${fieldName}`}
                  />
                  <span className="text-sm text-muted-foreground">
                    {field.value ? "True" : "False"}
                  </span>
                </div>
              ) : column.dataType === "date" ? (
                <Input
                  type="date"
                  {...field}
                  value={field.value || ""}
                  data-testid={`input-${fieldName}`}
                />
              ) : column.dataType === "number" ? (
                <Input
                  type="number"
                  placeholder="Enter number"
                  {...field}
                  value={field.value || ""}
                  data-testid={`input-${fieldName}`}
                />
              ) : fieldNombre.toLowerCase().includes("description") || 
                   fieldNombre.toLowerCase().includes("notes") ||
                   fieldNombre.toLowerCase().includes("comment") ? (
                <Textarea
                  placeholder={`Enter ${column.name.toLowerCase()}`}
                  {...field}
                  value={field.value || ""}
                  data-testid={`textarea-${fieldName}`}
                />
              ) : (
                <Input
                  placeholder={`Enter ${column.name.toLowerCase()}`}
                  {...field}
                  value={field.value || ""}
                  data-testid={`input-${fieldName}`}
                />
              )}
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" data-testid="modal-edit-row">
        <DialogHeader>
          <DialogTitle>
            {isNewRow ? "Add New Row" : "Editarar Row"}
          </DialogTitle>
          <DialogDescription>
            {isNewRow 
              ? "Fill in the details for the new row. Required fields are marked with an asterisk (*)"
              : "Update the row data. Required fields are marked with an asterisk (*)"
            }
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {columns.map(renderField)}
            </div>

            <div className="flex justify-end space-x-3 pt-6 border-t border-border">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                disabled={mutation.isPending}
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button 
                type="submit" 
                disabled={mutation.isPending}
                data-testid="button-save"
              >
                {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isNewRow ? "Create Row" : "Guardar Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
