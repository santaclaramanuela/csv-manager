import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Activity } from "lucide-react";
import type { CsvColumn } from "../../types";
import type { TableRow } from "@shared/schema";

interface QualityIssue {
  type: 'missing' | 'duplicate' | 'format' | 'outlier';
  column: string;
  count: number;
  description: string;
  severity: 'low' | 'medium' | 'high';
}

function DataQualityAnalysis({ data, columns }: { data: TableRow[], columns: CsvColumn[] }) {
  const issues: QualityIssue[] = [];

  // Check for missing values in required fields
  columns.filter(col => col.isRequired).forEach(column => {
    const missingCount = data.filter(row => {
      const value = row[column.name];
      return value === null || value === undefined || String(value).trim() === '';
    }).length;
    
    if (missingCount > 0) {
      issues.push({
        type: 'missing',
        column: column.name,
        count: missingCount,
        description: `Missing values in required field '${column.name}'`,
        severity: 'high'
      });
    }
  });

  // Check for format issues
  columns.forEach(column => {
    if (column.dataType === 'number') {
      const formatIssues = data.filter(row => {
        const value = row[column.name];
        if (value === null || value === undefined || String(value).trim() === '') return false;
        const cleanValue = String(value).trim().replace(/[,$%]/g, '');
        return isNaN(Number(cleanValue));
      }).length;
      
      if (formatIssues > 0) {
        issues.push({
          type: 'format',
          column: column.name,
          count: formatIssues,
          description: `Invalid number format in column '${column.name}'`,
          severity: 'medium'
        });
      }
    }
    
    if (column.dataType === 'date') {
      const dateIssues = data.filter(row => {
        const value = row[column.name];
        if (value === null || value === undefined || String(value).trim() === '') return false;
        const date = new Date(String(value));
        return isNaN(date.getTime()) || date.getFullYear() < 1900 || date.getFullYear() > 2100;
      }).length;
      
      if (dateIssues > 0) {
        issues.push({
          type: 'format',
          column: column.name,
          count: dateIssues,
          description: `Invalid date format in column '${column.name}'`,
          severity: 'medium'
        });
      }
    }
  });

  // Check for duplicates (based on first few columns)
  const keyColumnas = columns.slice(0, 3).map(col => col.name);
  const seen = new Set();
  const duplicates = data.filter(row => {
    const key = keyColumnas.map(col => String(row[col] || '')).join('|');
    if (seen.has(key)) {
      return true;
    }
    seen.add(key);
    return false;
  }).length;
  
  if (duplicates > 0) {
    issues.push({
      type: 'duplicate',
      column: keyColumnas.join(', '),
      count: duplicates,
      description: `Potential duplicate rows based on ${keyColumnas.join(', ')}`,
      severity: 'low'
    });
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-blue-600 bg-blue-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  if (issues.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No issues found</h3>
        <p className="text-gray-500">Your data quality looks great!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="text-center">
          <p className="text-2xl font-bold text-red-600">
            {issues.filter(i => i.severity === 'high').length}
          </p>
          <p className="text-sm text-muted-foreground">High Priority</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-yellow-600">
            {issues.filter(i => i.severity === 'medium').length}
          </p>
          <p className="text-sm text-muted-foreground">Medium Priority</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold text-blue-600">
            {issues.filter(i => i.severity === 'low').length}
          </p>
          <p className="text-sm text-muted-foreground">Low Priority</p>
        </div>
      </div>
      
      <div className="space-y-3">
        {issues.map((issue, index) => (
          <div key={index} className={`p-3 rounded-lg border ${getSeverityColor(issue.severity)}`}>
            <div className="flex items-center justify-between mb-1">
              <span className="font-medium capitalize">{issue.type} Issue</span>
              <Badge variant="outline" className={getSeverityColor(issue.severity)}>
                {issue.severity}
              </Badge>
            </div>
            <p className="text-sm mb-1">{issue.description}</p>
            <p className="text-xs text-muted-foreground">
              Affected records: {issue.count}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

interface DatosVisualizationProps {
  data: TableRow[];
  columns: CsvColumn[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

export function DatosVisualization({ data, columns }: DatosVisualizationProps) {
  const statistics = useMemo(() => {
    if (!data || data.length === 0) return null;

    const numericColumnas = columns.filter(col => col.dataType === 'number');
    const textColumnas = columns.filter(col => col.dataType === 'text');
    const dateColumnas = columns.filter(col => col.dataType === 'date');

    // Calculate basic statistics
    const stats = {
      totalRecords: data.length,
      numericSummary: {} as Record<string, any>,
      categoricalDistribution: {} as Record<string, any>,
      trends: [] as any[],
    };

    // Numeric column statistics
    numericColumnas.forEach(column => {
      const values = data.map(row => parseFloat(row[column.name])).filter(v => !isNaN(v));
      if (values.length > 0) {
        stats.numericSummary[column.name] = {
          min: Math.min(...values),
          max: Math.max(...values),
          average: values.reduce((sum, val) => sum + val, 0) / values.length,
          total: values.reduce((sum, val) => sum + val, 0),
        };
      }
    });

    // Categorical distribution for text columns
    textColumnas.slice(0, 3).forEach(column => {
      const distribution: Record<string, number> = {};
      data.forEach(row => {
        const value = row[column.name]?.toString() || 'Empty';
        distribution[value] = (distribution[value] || 0) + 1;
      });
      
      // Convert to chart format and limit to top 10
      stats.categoricalDistribution[column.name] = Object.entries(distribution)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10)
        .map(([name, value]) => ({ name, value }));
    });

    // Time-based trends for date columns
    if (dateColumnas.length > 0 && numericColumnas.length > 0) {
      const dateColumn = dateColumnas[0];
      const valueColumn = numericColumnas[0];
      
      const trends: Record<string, number> = {};
      data.forEach(row => {
        try {
          const date = new Date(row[dateColumn.name]);
          const value = parseFloat(row[valueColumn.name]);
          if (!isNaN(date.getTime()) && !isNaN(value)) {
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            trends[monthKey] = (trends[monthKey] || 0) + value;
          }
        } catch (e) {
          // Skip invalid dates
        }
      });

      stats.trends = Object.entries(trends)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([month, value]) => ({ month, value }));
    }

    return stats;
  }, [data, columns]);

  if (!statistics || data.length === 0) {
    return (
      <div className="text-center py-8">
        <BarChart3 className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <p className="text-muted-foreground">Sin datos available for visualization</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card data-testid="card-total-records">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Records</p>
                <p className="text-2xl font-bold text-foreground">
                  {statistics.totalRecords.toLocaleString()}
                </p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        {Object.entries(statistics.numericSummary).slice(0, 3).map(([column, stats]) => (
          <Card key={column} data-testid={`card-numeric-${column}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{column} (Avg)</p>
                  <p className="text-2xl font-bold text-foreground">
                    {stats.average?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Range: {stats.min} - {stats.max}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Numeric Datos Bar Charts */}
      {Object.entries(statistics.numericSummary).length > 0 && (
        <Card data-testid="card-numeric-charts">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5" />
              <span>Numeric Datos Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {Object.entries(statistics.numericSummary).slice(0, 2).map(([column, stats]) => {
                const chartDatos = [
                  { name: 'Minimum', value: stats.min },
                  { name: 'Average', value: stats.average },
                  { name: 'Maximum', value: stats.max },
                ];

                return (
                  <div key={column}>
                    <h4 className="font-medium mb-4">{column} Distribution</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="#0088FE" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Categorical Distribution Pie Charts */}
      {Object.entries(statistics.categoricalDistribution).length > 0 && (
        <Card data-testid="card-categorical-charts">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <PieChartIcon className="h-5 w-5" />
              <span>Categorical Datos Distribution</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {Object.entries(statistics.categoricalDistribution).map(([column, chartDatos]) => (
                <div key={column}>
                  <h4 className="font-medium mb-4">{column} Distribution</h4>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {chartDatos.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  
                  {/* Legend */}
                  <div className="flex flex-wrap gap-2 mt-4">
                    {chartDatos.slice(0, 6).map((entry: any, index: number) => (
                      <Badge key={entry.name} variant="outline" className="text-xs">
                        <div 
                          className="w-2 h-2 rounded-full mr-1" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        {entry.name}: {entry.value}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Time-based Trends */}
      {statistics.trends.length > 0 && (
        <Card data-testid="card-trends">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <span>Trends Over Time</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={statistics.trends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#0088FE" 
                  strokeWidth={2}
                  dot={{ fill: '#0088FE' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Datos Quality Insights */}
      <Card data-testid="card-data-quality">
        <CardHeader>
          <CardTitle>Datos Quality Issues</CardTitle>
        </CardHeader>
        <CardContent>
          <DataQualityAnalysis data={data} columns={columns} />
        </CardContent>
      </Card>
    </div>
  );
}
