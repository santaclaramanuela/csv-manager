import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow as UITableRow } from "../ui/table";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Badge } from "../ui/badge";
import { 
  ChevronLeft, 
  ChevronRight, 
  ChevronsLeft, 
  ChevronsRight,
  ArrowUp,
  ArrowDown,
  Edit,
  Trash2
} from "lucide-react";
import type { CsvColumn } from "../../types";
import type { TableRow } from "@shared/schema";

interface DataTableProps {
  data: TableRow[];
  columns: CsvColumn[];
  total: number;
  currentPage: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  onPageTamañoChange: (size: number) => void;
  onEditarRow?: (row: TableRow) => void;
  onEliminarRow?: (rowId: string) => void;
}

export function DatosTable({
  data,
  columns,
  total,
  currentPage,
  pageTamaño,
  onPageChange,
  onPageTamañoChange,
  onEditarRow,
  onEliminarRow,
}: DatosTableProps) {
  const [selectedFilas, setSelectedFilas] = useState<Set<string>>(new Set());
  const [sortColumn, setOrdenarColumn] = useState<string>("");
  const [sortDirection, setOrdenarDirection] = useState<"asc" | "desc">("asc");

  const totalPages = Math.ceil(total / pageTamaño);
  const startIndex = currentPage * pageTamaño + 1;
  const endIndex = Math.min((currentPage + 1) * pageTamaño, total);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedFilas(new Set(data.map(row => row.id)));
    } else {
      setSelectedFilas(new Set());
    }
  };

  const handleSelectRow = (rowId: string, checked: boolean) => {
    const newSelected = new Set(selectedFilas);
    if (checked) {
      newSelected.add(rowId);
    } else {
      newSelected.delete(rowId);
    }
    setSelectedFilas(newSelected);
  };

  const handleOrdenar = (columnNombre: string) => {
    if (sortColumn === columnNombre) {
      setOrdenarDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setOrdenarColumn(columnNombre);
      setOrdenarDirection("asc");
    }
  };

  const handleCellEditar = (row: TableRow, column: string, value: string) => {
    // Inline editing would be implemented here
    console.log("Editarar cell:", row.id, column, value);
  };

  const renderCellValue = (value: any, column: CsvColumn) => {
    if (value == null || value === "") {
      return <span className="text-muted-foreground italic">Empty</span>;
    }

    switch (column.dataType) {
      case "number":
        return typeof value === "number" ? value.toLocaleString() : value;
      case "date":
        try {
          return new Date(value).toLocaleDateString();
        } catch {
          return value;
        }
      case "boolean":
        return (
          <Badge variant={value ? "default" : "secondary"}>
            {value ? "True" : "False"}
          </Badge>
        );
      default:
        return value.toString();
    }
  };

  return (
    <div className="space-y-4">
      {/* Table */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <UITableRow>
              <TableHead className="w-12">
                <Checkbox
                  checked={selectedRows.size === data.length && data.length > 0}
                  onCheckedChange={handleSelectAll}
                  data-testid="checkbox-select-all"
                />
              </TableHead>
              {columns.map((column) => (
                <TableHead 
                  key={column.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => handleOrdenar(column.name)}
                  data-testid={`header-${column.name}`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">{column.name}</span>
                    {column.isRequired && (
                      <span className="text-destructive">*</span>
                    )}
                    {sortColumn === column.name && (
                      sortDirection === "asc" ? 
                        <ArrowUp className="h-4 w-4" /> : 
                        <ArrowDown className="h-4 w-4" />
                    )}
                  </div>
                </TableHead>
              ))}
              {(onEditarRow || onEliminarRow) && (
                <TableHead className="w-24">Acciones</TableHead>
              )}
            </UITableRow>
          </TableHeader>
          <TableBody>
            {data.length === 0 ? (
              <UITableRow>
                <TableCell 
                  colSpan={columns.length + (onEditRow || onDeleteRow ? 2 : 1)} 
                  className="text-center py-12 text-muted-foreground"
                >
                  Sin datos available
                </TableCell>
              </UITableRow>
            ) : (
              data.map((row, index) => (
                <UITableRow 
                  key={row.id} 
                  className="hover:bg-muted/50"
                  data-testid={`row-${index}`}
                >
                  <TableCell>
                    <Checkbox
                      checked={selectedRows.has(row.id)}
                      onCheckedChange={(checked) => handleSelectRow(row.id, checked as boolean)}
                      data-testid={`checkbox-row-${index}`}
                    />
                  </TableCell>
                  {columns.map((column) => (
                    <TableCell 
                      key={column.id}
                      className="max-w-xs truncate"
                      data-testid={`cell-${index}-${column.name}`}
                    >
                      <div className="editable-cell p-2 rounded hover:bg-muted/50 cursor-text">
                        {renderCellValue(row[column.name], column)}
                      </div>
                    </TableCell>
                  ))}
                  {(onEditarRow || onEliminarRow) && (
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {onEditarRow && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-primary hover:text-primary"
                            onClick={() => onEditarRow(row)}
                            data-testid={`button-edit-${index}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {onEliminarRow && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => onEliminarRow(row.id)}
                            data-testid={`button-delete-${index}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  )}
                </UITableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="bg-muted/30 px-6 py-3 border-t border-border flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <span className="text-sm text-muted-foreground">
            Showing <span className="font-medium">{startIndex}-{endIndex}</span> of{" "}
            <span className="font-medium">{total.toLocaleString()}</span> records
          </span>
          <Select 
            value={pageSize.toString()} 
            onValueChange={(value) => onPageTamañoChange(parseInt(value))}
          >
            <SelectTrigger className="w-32" data-testid="select-page-size">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="25">25 per page</SelectItem>
              <SelectItem value="50">50 per page</SelectItem>
              <SelectItem value="100">100 per page</SelectItem>
              <SelectItem value="200">200 per page</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => onPageChange(0)}
            disabled={currentPage === 0}
            data-testid="button-first-page"
          >
            <ChevronsLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 0}
            data-testid="button-prev-page"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <div className="flex items-center space-x-1">
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const pageNum = Math.max(0, Math.min(totalPages - 5, currentPage - 2)) + i;
              return (
                <Button
                  key={pageNum}
                  variant={currentPage === pageNum ? "default" : "outline"}
                  size="icon"
                  onClick={() => onPageChange(pageNum)}
                  data-testid={`button-page-${pageNum}`}
                >
                  {pageNum + 1}
                </Button>
              );
            })}
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage >= totalPages - 1}
            data-testid="button-next-page"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onPageChange(totalPages - 1)}
            disabled={currentPage >= totalPages - 1}
            data-testid="button-last-page"
          >
            <ChevronsRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Bulk Acciones */}
      {selectedFilas.size > 0 && (
        <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">
              {selectedFilas.size} row{selectedFilas.size === 1 ? "" : "s"} selected
            </span>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedFilas(new Set())}
                data-testid="button-clear-selection"
              >
                Clear Selection
              </Button>
              {onEliminarRow && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => {
                    // TODO: Implement bulk delete
                    console.log("Bulk delete:", Array.from(selectedFilas));
                  }}
                  data-testid="button-bulk-delete"
                >
                  Eliminar Selected
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
