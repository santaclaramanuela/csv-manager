import { Card, CardContent } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Badge } from "../ui/badge";
import { Search, Filter, X } from "lucide-react";
import type { CsvColumn } from "../../types";

interface DataFiltersProps {
  columns: CsvColumn[];
  searchTerm: string;
  selectedColumn: string;
  onSearchChange: (term: string) => void;
  onColumnChange: (column: string) => void;
  onClearFiltros: () => void;
}

export function DatosFiltros({
  columns,
  searchTerm,
  selectedColumn,
  onBuscarChange,
  onColumnChange,
  onClearFiltros,
}: DatosFiltrosProps) {
  const hasActiveFiltros = searchTerm || selectedColumn;

  return (
    <Card className="mb-6" data-testid="card-data-filters">
      <CardContent className="pt-6">
        <div className="flex flex-wrap items-center gap-4">
          {/* Global Buscar */}
          <div className="flex-1 min-w-64">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar across all columns..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => onBuscarChange(e.target.value)}
                data-testid="input-global-search"
              />
            </div>
          </div>

          {/* Column Filter */}
          <div className="min-w-48">
            <Select value={selectedColumn} onValueChange={onColumnChange}>
              <SelectTrigger data-testid="select-column-filter">
                <SelectValue placeholder="Filter by column" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Columnas</SelectItem>
                {columns.map((column) => (
                  <SelectItem key={column.id} value={column.name}>
                    <div className="flex items-center space-x-2">
                      <span>{column.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {column.dataType}
                      </Badge>
                      {column.isRequired && (
                        <span className="text-destructive text-xs">*</span>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Advanced Filtros Button */}
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
            data-testid="button-advanced-filters"
          >
            <Filter className="h-4 w-4" />
            <span>Advanced Filtros</span>
          </Button>

          {/* Clear Filtros */}
          {hasActiveFiltros && (
            <Button 
              variant="ghost" 
              onClick={onClearFilters}
              className="text-muted-foreground hover:text-foreground"
              data-testid="button-clear-filters"
            >
              <X className="h-4 w-4 mr-1" />
              Clear Filtros
            </Button>
          )}
        </div>

        {/* Active Filtros Display */}
        {hasActiveFiltros && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium text-muted-foreground">Active filters:</span>
            
            {searchTerm && (
              <Badge variant="secondary" className="flex items-center space-x-1">
                <span>Buscar: "{searchTerm}"</span>
                <button 
                  onClick={() => onBuscarChange("")}
                  classNombre="ml-1 hover:bg-muted rounded-full p-0.5"
                  data-testid="button-clear-search"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            
            {selectedColumn && (
              <Badge variant="secondary" className="flex items-center space-x-1">
                <span>Column: {selectedColumn}</span>
                <button 
                  onClick={() => onColumnChange("")}
                  classNombre="ml-1 hover:bg-muted rounded-full p-0.5"
                  data-testid="button-clear-column"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
          </div>
        )}

        {/* Quick Filter Suggestions */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted-foreground">Quick filters:</span>
          
          {columns.slice(0, 4).map((column) => (
            <Button
              key={column.id}
              variant="outline"
              size="sm"
              onClick={() => onColumnChange(column.name)}
              classNombre={`text-xs ${selectedColumn === column.name ? 'bg-primary text-primary-foreground' : ''}`}
              data-testid={`button-quick-filter-${column.name}`}
            >
              {column.name}
            </Button>
          ))}
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onColumnChange("")}
            classNombre="text-xs"
            data-testid="button-show-all"
          >
            Show All
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
