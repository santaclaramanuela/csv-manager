import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Header } from "../components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Skeleton } from "../components/ui/skeleton";
import { DataTable } from "../components/data/data-table";
import { DataFilters } from "../components/data/data-filters";
import { DataVisualization } from "../components/charts/data-visualization";
import { EditRowModal } from "../components/modals/edit-row-modal";
import { DeleteConfirmationModal } from "../components/modals/delete-confirmation-modal";
import { useToast } from "../hooks/use-toast";
import { useAuth } from "../hooks/use-auth";
import { formatFileSize, formatDate, downloadCsv } from "../lib/csv-utils";
import { getAuthToken } from "../lib/auth";
import { 
  ArrowLeft, 
  Download, 
  FileSpreadsheet, 
  BarChart3, 
  Plus,
  Share,
  Trash2
} from "lucide-react";
import type { FileWithStats, CsvColumn } from "../types";
import type { TableRow } from "@shared/schema";

interface FileData {
  data: TableRow[];
  total: number;
  columns: CsvColumn[];
}

export default function FileViewer() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [currentPage, setCurrentPage] = useState(0);
  const [pageTamaño, setPageTamaño] = useState(50);
  const [searchTerm, setBuscarTerm] = useState("");
  const [selectedColumn, setSelectedColumn] = useState("");
  const [showVisualization, setShowVisualization] = useState(false);
  const [editingRow, setEditaringRow] = useState<TableRow | null>(null);
  const [deletingRowId, setDeletingRowId] = useState<string | null>(null);

  const { data: file, isCargando: fileCargando } = useQuery<FileWithStats>({
    queryKey: ["/api/files", id],
    enabled: !!id,
  });

  const { data: fileDatos, isCargando: dataCargando, refetch } = useQuery<FileData>({
    queryKey: ["/api/files", id, "data", currentPage, pageTamaño, searchTerm, selectedColumn],
    enabled: !!id && file?.status === "completed",
  });

  const handleExport = (format: "csv" | "excel") => {
    if (!fileDatos?.data || fileDatos.data.length === 0) {
      toast({
        title: "Export failed",
        description: "Sin datos available to export",
        variant: "destructive",
      });
      return;
    }

    if (format === "csv") {
      downloadCsv(fileDatos.data, file?.originalNombre || "data.csv");
      toast({
        title: "Export successful",
        description: "CSV file downloaded",
      });
    } else {
      // TODO: Implement Excel export
      toast({
        title: "Excel export",
        description: "Excel export functionality coming soon",
      });
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      toast({
        title: "Link copied",
        description: "File share link copied to clipboard",
      });
    }).catch(() => {
      toast({
        title: "Share failed",
        description: "No se pudo copiar el enlace al portapapeles",
        variant: "destructive",
      });
    });
  };

  const handleEliminarFile = async () => {
    if (!file || !user) return;

    try {
      const token = getAuthToken();
      const response = await fetch(`/api/files/${file.id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Falló to delete file');
      }

      toast({
        title: "Archivo eliminado",
        description: "File has been successfully deleted",
      });
      
      setLocation("/");
    } catch (error) {
      toast({
        title: "Eliminar failed",
        description: "Unable to delete file",
        variant: "destructive",
      });
    }
  };

  const canEditar = user && (user.role === "admin" || user.role === "editor");
  const isOwner = user && file && file.userId === user.id;

  if (!id) {
    setLocation("/");
    return null;
  }

  if (fileCargando) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="space-y-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-96 w-full" />
          </div>
        </main>
      </div>
    );
  }

  if (!file) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="text-center py-12">
            <CardContent>
              <h2 className="text-2xl font-bold text-foreground mb-4">File Not Found</h2>
              <p className="text-muted-foreground mb-6">
                The file you're looking for doesn't exist or you don't have permission to view it.
              </p>
              <Button onClick={() => setLocation("/")} data-testid="button-back-to-dashboard">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Panel
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* File Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground" data-testid="text-file-title">
                {file.originalNombre}
              </h1>
              <div className="flex items-center space-x-4 mt-2">
                <Badge 
                  variant={file.status === "completed" ? "default" : file.status === "error" ? "destructive" : "secondary"}
                  data-testid="badge-file-status"
                >
                  {file.status}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {formatFileTamaño(file.fileTamaño)} • {file.recordCount.toLocaleString()} records
                </span>
                <span className="text-sm text-muted-foreground">
                  Subired {formatDate(file.uploadedAt)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setShowVisualization(!showVisualization)}
              data-testid="button-toggle-charts"
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              {showVisualization ? "Hide Charts" : "Show Charts"}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => handleExport("csv")}
              data-testid="button-export-csv"
            >
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
            
            <Button 
              variant="outline" 
              onClick={handleShare}
              data-testid="button-share"
            >
              <Share className="mr-2 h-4 w-4" />
              Share
            </Button>

            {canEditar && isOwner && (
              <Button 
                variant="destructive" 
                onClick={() => setDeletingRowId("file")}
                data-testid="button-delete-file"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Eliminar File
              </Button>
            )}
          </div>
        </div>

        {file.status === "error" && (
          <Card className="mb-6 border-destructive/20 bg-destructive/5">
            <CardContent className="pt-6">
              <div className="flex items-start space-x-3">
                <Trash2 className="h-5 w-5 text-destructive mt-0.5" />
                <div>
                  <h3 className="font-medium text-destructive">Procesando Error</h3>
                  <p className="text-sm text-destructive/80 mt-1">
                    {file.errorMessage || "Ocurrió un error while processing this file."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {file.status === "processing" && (
          <Card className="mb-6 border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-900/20">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-3">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-yellow-600"></div>
                <div>
                  <h3 className="font-medium text-yellow-800 dark:text-yellow-200">
                    Procesando File
                  </h3>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                    Your file is being processed. This page will update automatically when complete.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {file.status === "completed" && (
          <>
            {/* Visualización de datos */}
            {showVisualization && fileDatos && (
              <Card className="mb-6" data-testid="card-visualization">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 size={20} />
                    <span>Visualización de datos</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <DataVisualization 
                    data={fileData.data} 
                    columns={fileData.columns}
                  />
                </CardContent>
              </Card>
            )}

            {/* Datos Filtros */}
            <DataFilters
              columns={fileData?.columns || []}
              searchTerm={searchTerm}
              selectedColumn={selectedColumn}
              onSearchChange={setSearchTerm}
              onColumnChange={setSelectedColumn}
              onClearFilters={() => {
                setBuscarTerm("");
                setSelectedColumn("");
              }}
            />

            {/* Datos Table */}
            <Card data-testid="card-data-table">
              <CardHeader className="border-b border-border">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <FileSpreadsheet size={20} />
                    <span>Datos Ver</span>
                  </CardTitle>
                  {canEditar && (
                    <Button 
                      onClick={() => setEditaringRow({ id: "new", rowIndex: -1 })}
                      data-testid="button-add-row"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Row
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {dataCargando ? (
                  <div className="p-6">
                    <Skeleton className="h-96 w-full" />
                  </div>
                ) : fileDatos ? (
                  <DataTable
                    data={fileData.data}
                    columns={fileData.columns}
                    total={fileData.total}
                    currentPage={currentPage}
                    pageSize={pageSize}
                    onPageChange={setCurrentPage}
                    onPageSizeChange={setPageSize}
                    onEditRow={canEdit ? setEditingRow : undefined}
                    onDeleteRow={canEdit ? (rowId) => setDeletingRowId(rowId) : undefined}
                  />
                ) : (
                  <div className="p-8 text-center text-muted-foreground">
                    Sin datos available
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}

        {/* Modals */}
        {editingRow && (
          <EditRowModal
            row={editingRow}
            columns={fileData?.columns || []}
            fileId={file.id}
            isOpen={true}
            onClose={() => setEditaringRow(null)}
            onSuccess={() => {
              setEditaringRow(null);
              refetch();
            }}
          />
        )}

        {deletingRowId && (
          <DeleteConfirmationModal
            isOpen={true}
            onClose={() => setDeletingRowId(null)}
            onConfirm={async () => {
              if (deletingRowId === "file") {
                await handleEliminarFile();
              } else {
                // TODO: Implement row deletion
                toast({
                  title: "Fila eliminada",
                  description: "Row has been successfully deleted",
                });
                refetch();
              }
              setDeletingRowId(null);
            }}
            title={deletingRowId === "file" ? "Eliminar File" : "Eliminar Row"}
            description={
              deletingRowId === "file" 
                ? "Are you sure you want to delete this entire file? This action cannot be undone."
                : "¿Seguro que querés eliminar esta fila? This action cannot be undone."
            }
          />
        )}
      </main>
    </div>
  );
}
