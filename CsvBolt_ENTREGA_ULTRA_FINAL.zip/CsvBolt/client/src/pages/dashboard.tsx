import { useAuth } from "../hooks/use-auth";
import { Header } from "../components/layout/header";
import { StatsCards } from "../components/dashboard/stats-cards";
import { FileUpload } from "../components/dashboard/file-upload";
import { FilesList } from "../components/dashboard/files-list";

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    return null; // This will be handled by the auth check in App.tsx
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Welcome back, {user.username}!
          </h1>
          <p className="text-muted-foreground">
            Manage your CSV files and analyze your data
          </p>
        </div>
        
        <StatsCards />
        <FileUpload />
        <FilesList />
      </main>
    </div>
  );
}
