import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Header } from "../components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Badge } from "../components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Skeleton } from "../components/ui/skeleton";
import { useToast } from "../hooks/use-toast";
import { formatFileSize, formatDate } from "../lib/csv-utils";
import { Users, ArrowRight, Database } from "lucide-react";
import type { CsvFile } from "../types";
import type { MergeOperation } from "@shared/schema";

export default function MergePage() {
  const [sourceFileId, setSourceFileId] = useState<string>("");
  const [targetFileId, setTargetFileId] = useState<string>("");
  const [mergeKey, setMergeKey] = useState<string>("");
  const { toast } = useToast();

  const { data: files, isCargando: filesCargando } = useQuery<CsvFile[]>({
    queryKey: ["/api/files/public"],
  });

  const { data: mergeOperations, isCargando: operationsCargando } = useQuery<MergeOperation[]>({
    queryKey: ["/api/merge"],
  });

  const createMergeMutation = useMutation({
    mutationFn: async (data: { sourceFileId: string; targetFileId: string; mergeKey: string }) => {
      const response = await fetch('/api/merge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Merge operation failed');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Merge operation created",
        description: "Your files are being merged",
      });
      setSourceFileId("");
      setTargetFileId("");
      setMergeKey("");
    },
    onError: (error: any) => {
      toast({
        title: "Merge failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleMerge = () => {
    if (!sourceFileId || !targetFileId || !mergeKey) {
      toast({
        title: "Missing information",
        description: "Please select both files and specify a merge key",
        variant: "destructive",
      });
      return;
    }

    if (sourceFileId === targetFileId) {
      toast({
        title: "Invalid selection",
        description: "Source and target files must be different",
        variant: "destructive",
      });
      return;
    }

    createMergeMutation.mutate({ sourceFileId, targetFileId, mergeKey });
  };

  const completedArchivos = files?.filter(file => file.status === "completed") || [];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-primary/10 text-primary p-2 rounded-lg">
              <Users size={24} />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">File Merge (Público Access)</h1>
              <p className="text-muted-foreground">
                Merge CSV files together - available to all users
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Merge Configuration */}
          <Card data-testid="card-merge-config">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Database size={20} />
                <span>Create Merge Operation</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Source File
                  </label>
                  <Select value={sourceFileId} onValueChange={setSourceFileId}>
                    <SelectTrigger data-testid="select-source-file">
                      <SelectValue placeholder="Select source file" />
                    </SelectTrigger>
                    <SelectContent>
                      {completedArchivos.map(file => (
                        <SelectItem key={file.id} value={file.id}>
                          {file.originalNombre} ({formatFileTamaño(file.fileTamaño)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-center">
                  <ArrowRight className="h-6 w-6 text-muted-foreground" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Target File
                  </label>
                  <Select value={targetFileId} onValueChange={setTargetFileId}>
                    <SelectTrigger data-testid="select-target-file">
                      <SelectValue placeholder="Select target file" />
                    </SelectTrigger>
                    <SelectContent>
                      {completedArchivos.map(file => (
                        <SelectItem 
                          key={file.id} 
                          value={file.id}
                          disabled={file.id === sourceFileId}
                        >
                          {file.originalNombre} ({formatFileTamaño(file.fileTamaño)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Merge Key (Column Nombre)
                  </label>
                  <Select value={mergeKey} onValueChange={setMergeKey}>
                    <SelectTrigger data-testid="select-merge-key">
                      <SelectValue placeholder="Select column to merge on" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="id">ID</SelectItem>
                      <SelectItem value="name">Nombre</SelectItem>
                      <SelectItem value="email">Correo</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="custom">Custom Column</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                onClick={handleMerge}
                disabled={createMergeMutation.isPending || !sourceFileId || !targetFileId || !mergeKey}
                className="w-full"
                data-testid="button-create-merge"
              >
                {createMergeMutation.isPending ? "Creating Merge..." : "Create Merge Operation"}
              </Button>
            </CardContent>
          </Card>

          {/* Available Archivos */}
          <Card data-testid="card-available-files">
            <CardHeader>
              <CardTitle>Available Archivos</CardTitle>
            </CardHeader>
            <CardContent>
              {filesCargando ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center space-x-3">
                      <Skeleton className="h-8 w-8 rounded" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {completedArchivos.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">
                      No completed files available for merging
                    </p>
                  ) : (
                    completedArchivos.map(file => (
                      <div 
                        key={file.id} 
                        className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50"
                        data-testid={`file-item-${file.id}`}
                      >
                        <div className="flex-1">
                          <div className="font-medium text-foreground">
                            {file.originalNombre}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {formatFileTamaño(file.fileTamaño)} • {file.rowCount.toLocaleString()} records
                          </div>
                        </div>
                        <Badge variant="outline">
                          {file.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Merge Operations History */}
        <Card className="mt-8" data-testid="card-merge-history">
          <CardHeader>
            <CardTitle>Merge Operations History</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {operationsCargando ? (
              <div className="p-6">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 mb-4">
                    <Skeleton className="h-12 w-12 rounded" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-3 w-1/2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source File</TableHead>
                    <TableHead>Target File</TableHead>
                    <TableHead>Merge Key</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {!mergeOperations || mergeOperations.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No merge operations yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    mergeOperations.map((operation) => (
                      <TableRow key={operation.id} data-testid={`merge-operation-${operation.id}`}>
                        <TableCell className="font-medium">
                          {operation.sourceFileId}
                        </TableCell>
                        <TableCell>
                          {operation.targetFileId}
                        </TableCell>
                        <TableCell>
                          {operation.mergeKey}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={
                              operation.status === "completed" ? "default" : 
                              operation.status === "error" ? "destructive" : "secondary"
                            }
                          >
                            {operation.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(operation.createdAt)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
